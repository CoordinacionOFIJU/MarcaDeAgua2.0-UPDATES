'use strict';
/* Marca de agua 2.0 · OFIJU — interfaz */

// Cualquier error se muestra en pantalla para poder informarlo.
function mostrarError(msg) {
  const a = document.getElementById('aviso');
  if (a) { a.hidden = false; a.textContent = 'Error interno: ' + msg; }
}
window.addEventListener('error', (e) => mostrarError(e.message + (e.filename ? ` (${e.filename.split('/').pop()}:${e.lineno})` : '')));
window.addEventListener('unhandledrejection', (e) => mostrarError(String(e.reason && e.reason.message || e.reason)));
if (!window.LOGOS) mostrarError('no se cargó logos.js');
if (!window.api) mostrarError('no se cargó preload.js');

const $ = (id) => document.getElementById(id);
const ipc = window.api;
const LOGO_PROP = 300 / 548; // alto / ancho del logo

/* ---------- estado ---------- */
const hoy = new Date();
const dd = (n) => String(n).padStart(2, '0');
const DATOS_EJEMPLO = {
  fecha: `${dd(hoy.getDate())}/${dd(hoy.getMonth() + 1)}/${String(hoy.getFullYear()).slice(2)}`,
  nombre: 'Dr. Gonzalez Mariano Facundo',
  cargo: 'Abogado defensor',
  localidad: 'Bella Vista',
  tipo: 'Audiencia concentrada',
  lju: '2645/26',
  lif: '15478/26',
  frase1: 'Quien asume la plena responsabilidad por la adecuada custodia de este material.',
  frase2: 'Original resguardado en repositorio institucional',
  dependencia: 'OFIJU Santo Tomé'
};
// La dependencia se recuerda: cada oficina comparte siempre desde la misma.
try { const dg = localStorage.getItem('marca2.dependencia'); if (dg !== null) DATOS_EJEMPLO.dependencia = dg; } catch (_) {}
const AJUSTES_INICIALES = {
  logo: { x: 0.03, y: 0.04, w: 0.22, transp: 50, fondo: 0, l1: 'GRABACIÓN', l2: 'COMPARTIDA' },
  texto: { x: 0.03, y: 0.62, tam: 2.5, color: '#FFFFFF', fondo: 50, formato: 'original' },
  alto: 720,
  modo: 'rapido'
};

function cargarAjustes() {
  try {
    // cada apertura arranca con logo y texto de fábrica; solo se recuerdan resolución y tipo de proceso
    const a = JSON.parse(localStorage.getItem('marca2.ajustes') || 'null');
    const base = JSON.parse(JSON.stringify(AJUSTES_INICIALES));
    if (a) { if (a.alto) base.alto = a.alto; if (a.modo) base.modo = a.modo; }
    return base;
  } catch (_) {}
  return JSON.parse(JSON.stringify(AJUSTES_INICIALES));
}
function guardarAjustes() {
  try { const { l1, l2, ...logo } = S.logo; localStorage.setItem('marca2.ajustes', JSON.stringify({ logo, texto: S.texto, alto: S.alto, modo: S.modo })); } catch (_) {}
}

const S = {
  ...cargarAjustes(),
  datos: { ...DATOS_EJEMPLO },
  videos: [],          // { ruta, nombre, info, estado, pct, salida, error, zonas, t }
  sel: -1,
  zonaSel: null,
  procesando: false,
  ffmpeg: true,
  cuadroDe: null
};
let idZona = 1;
const actual = () => S.videos[S.sel] || null;

/* ---------- utilidades ---------- */
const nombreZona = (z, i) => `Zona ${i + 1} · ${z.tipo === 'negro' ? 'Cuadro negro' : 'Cuadro de desenfoque'}`;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
function fmt(s) {
  s = Math.max(0, Math.round(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return h ? `${h}:${dd(m)}:${dd(x)}` : `${dd(m)}:${dd(x)}`;
}
function fmtLargo(s) {
  s = Math.max(0, Math.round(s || 0));
  return `${dd(Math.floor(s / 3600))}:${dd(Math.floor((s % 3600) / 60))}:${dd(s % 60)}`;
}
function leerTiempo(txt) {
  const t = String(txt || '').trim();
  if (!t) return null;
  const p = t.split(':').map((n) => parseFloat(n.replace(',', '.')));
  if (p.some(isNaN)) return null;
  return p.reduce((acc, n) => acc * 60 + n, 0);
}
const CRUZ = '<svg width="10" height="10" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
function conCruz(boton) { boton.innerHTML = CRUZ; return boton; }
function el(tag, props = {}, ...hijos) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  hijos.flat().forEach((h) => h != null && e.append(h));
  return e;
}

/* ---------- texto de la marca ---------- */
// Corta un texto en renglones de hasta n letras, solo en los espacios.
function partir(txt, n) {
  const out = []; let cur = '';
  for (const w of txt.split(/\s+/).filter(Boolean)) {
    if (cur && (cur + ' ' + w).length > n) { out.push(cur); cur = w; } else cur = cur ? cur + ' ' + w : w;
  }
  if (cur) out.push(cur);
  return out;
}
// Parte en dos renglones lo más parejos posible (corte en un espacio).
function enDos(txt) {
  const ws = txt.split(/\s+/).filter(Boolean);
  if (ws.length < 2) return [txt];
  let mejor = 1, dif = Infinity;
  for (let i = 1; i < ws.length; i++) {
    const d = Math.abs(ws.slice(0, i).join(' ').length - ws.slice(i).join(' ').length);
    if (d < dif) { dif = d; mejor = i; }
  }
  return [ws.slice(0, mejor).join(' '), ws.slice(mejor).join(' ')];
}
// Devuelve { bloques: [[renglón, ...], ...], hueco: separación entre bloques en renglones }
function lineas() {
  const d = S.datos, f = S.texto.formato || 'original';
  const fecha = d.fecha.trim();
  const nombre = d.nombre.trim().toUpperCase(), cargo = d.cargo.trim().toUpperCase(), loc = d.localidad.trim().toUpperCase();
  const f1 = d.frase1.trim(), f2 = d.frase2.trim(), dep = d.dependencia.trim().toUpperCase();
  const tipo = d.tipo.trim().toUpperCase(), lju = d.lju.trim(), lif = d.lif.trim();
  if (f === 'original') {
    const A = [`COPIA AUDIOVISUAL - entregada el día ${fecha} a:`, [nombre, cargo, loc].filter(Boolean).join(' - ')];
    if (f1) A.push(f1);
    const meta = [];
    if (tipo) meta.push(`Tipo De Audiencia: ${tipo}`);
    if (lju) meta.push(`LJU: ${lju}`);
    if (lif) meta.push(`LIF/SIGEF: ${lif}`);
    const B = [];
    if (meta.length) B.push(meta.join('  |  '));
    if (dep) B.push(`Compartido por: ${dep}`);
    if (f2) B.push(f2);
    return { bloques: B.length ? [A, B] : [A], hueco: 1 };
  }
  const bl = [];
  const nums = [lju && `LJU: ${lju}`, lif && `LIF/SIGEF: ${lif}`].filter(Boolean);
  if (f === 'compacta') {
    bl.push(['COPIA AUDIOVISUAL', `entregada el día ${fecha} a:`]);
    bl.push([nombre, [cargo, loc].filter(Boolean).join(' - ')].filter(Boolean));
    if (f1) bl.push(f1.length > 45 ? enDos(f1) : [f1]);
    const c = [];
    if (tipo) c.push(`Tipo De Audiencia: ${tipo}`);
    if (nums.length) c.push(nums.join('  |  '));
    if (c.length) bl.push(c);
    if (dep) bl.push([`Compartido por: ${dep}`]);
    if (f2) bl.push(f2.length > 45 ? enDos(f2) : [f2]);
  } else {
    bl.push(['COPIA AUDIOVISUAL', 'entregada el día', `${fecha} a:`]);
    bl.push([...(nombre.length > 18 ? enDos(nombre) : [nombre]), cargo, loc].filter(Boolean));
    if (f1) bl.push(partir(f1, 22));
    const c = [];
    if (tipo) c.push('Tipo De Audiencia:', ...partir(tipo, 22));
    c.push(...nums);
    if (c.length) bl.push(c);
    if (dep) bl.push(['Compartido por:', ...partir(dep, 22)]);
    if (f2) bl.push(partir(f2, 22));
  }
  return { bloques: bl.filter((x) => x.length), hueco: 0.4 };
}
function estiloTexto(color) {
  const oscuro = color.toUpperCase() === '#000000';
  const a = (1 - (S.texto.fondo ?? 50) / 100).toFixed(2); // transparencia del fondo del texto
  return { caja: oscuro ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a})`, sombra: oscuro ? null : 'rgba(0,0,0,0.9)' };
}
const FUENTE = '"Segoe UI", Arial, sans-serif';

/* ---------- capa PNG (logo + texto) para ffmpeg ---------- */
const imgMarca = new Image();
imgMarca.src = window.LOGOS.marca;

/* ---------- logo con texto propio (rombo + dos líneas) ---------- */
const LOGO_DEF = ['GRABACIÓN', 'COMPARTIDA'];
const ISO_COL = { top: '#1B7FAF', side: '#0D679B', bot: '#115473' };
let logoPedido = 0;
async function dibujarLogo() {
  const n = ++logoPedido;
  const t1 = (S.logo.l1 || '').trim().toUpperCase();
  const t2 = (S.logo.l2 || '').trim().toUpperCase();
  try { await Promise.all([document.fonts.load('100px OFIJUOficialBold'), document.fonts.load('100px OFIJUOficial')]); } catch (_) {}
  if (n !== logoPedido) return;
  const K = 4, c = document.createElement('canvas');
  c.width = 548 * K; c.height = 300 * K;
  const g = c.getContext('2d');
  g.scale(K, K);
  for (const p of window.LOGOS.iso) { g.fillStyle = ISO_COL[p.k]; g.fill(new Path2D(p.d)); }
  // cada línea ocupa el ancho de "OFIJU" del logo oficial; si es larga se achica
  const X = 264.92, W = 282.24, GAP = 14;
  const medir = (fam, txt, tope) => {
    g.font = `100px ${fam}`;
    const m = g.measureText(txt);
    const izq = m.actualBoundingBoxLeft, ancho = izq + m.actualBoundingBoxRight;
    const asc = m.actualBoundingBoxAscent, desc = m.actualBoundingBoxDescent;
    let k = W / ancho;
    if ((asc + desc) * k > tope) k = tope / (asc + desc);
    return { fam, txt, k, izq, asc, alto: (asc + desc) * k };
  };
  const ls = [];
  if (t1) ls.push(medir('OFIJUOficialBold', t1, 57.3));
  if (t2) ls.push(medir('OFIJUOficial', t2, 44.5));
  const total = ls.reduce((s2, l) => s2 + l.alto, 0) + GAP * Math.max(0, ls.length - 1);
  let y = 150 - total / 2;
  g.fillStyle = '#FFFFFF';
  for (const l of ls) {
    g.font = `${100 * l.k}px ${l.fam}`;
    g.fillText(l.txt, X + l.izq * l.k, y + l.asc * l.k);
    y += l.alto + GAP;
  }
  const url = c.toDataURL('image/png');
  imgMarca.src = url;
  $('imgMarca').src = url;
}

async function generarCapa(ow, oh) {
  if (!imgMarca.complete) await new Promise((r) => { imgMarca.onload = r; imgMarca.onerror = r; });
  const c = document.createElement('canvas');
  c.width = ow; c.height = oh;
  const g = c.getContext('2d');
  // logo
  const lw = S.logo.w * ow, lh = lw * LOGO_PROP;
  const fondo = (S.logo.fondo || 0) / 100;
  if (fondo > 0) {
    const pad = lw * 0.06, r = lw * 0.08;
    g.fillStyle = `rgba(0,0,0,${fondo})`;
    g.beginPath();
    g.roundRect(S.logo.x * ow - pad, S.logo.y * oh - pad, lw + 2 * pad, lh + 2 * pad, r);
    g.fill();
  }
  g.globalAlpha = 1 - S.logo.transp / 100;
  g.drawImage(imgMarca, S.logo.x * ow, S.logo.y * oh, lw, lh);
  g.globalAlpha = 1;
  // texto
  const T = lineas();
  const fs = (S.texto.tam / 100) * oh, lh2 = fs * 1.35, pad = fs * 0.6;
  g.font = `600 ${fs}px ${FUENTE}`;
  const todas = T.bloques.flat();
  const ancho = Math.max(...todas.map((l) => g.measureText(l).width));
  const alto = todas.length * lh2 + (T.bloques.length - 1) * T.hueco * lh2;
  const x = S.texto.x * ow, y = S.texto.y * oh;
  const est = estiloTexto(S.texto.color);
  g.fillStyle = est.caja;
  g.fillRect(x, y, ancho + 2 * pad, alto + 2 * pad);
  g.textBaseline = 'middle';
  let ty = y + pad + lh2 / 2;
  T.bloques.forEach((bq, bi) => {
    if (bi) ty += T.hueco * lh2;
    bq.forEach((l) => {
      if (est.sombra) { g.fillStyle = est.sombra; g.fillText(l, x + pad + fs * 0.06, ty + fs * 0.06); }
      g.fillStyle = S.texto.color;
      g.fillText(l, x + pad, ty);
      ty += lh2;
    });
  });
  return c.toDataURL('image/png');
}

/* ---------- vista previa ---------- */
const etapa = $('etapa'), etapaCaja = $('etapaCaja');
let aspecto = 16 / 9;

function ajustarEtapa() {
  const r = etapaCaja.getBoundingClientRect();
  let w = r.width, h = w / aspecto;
  if (h > r.height) { h = r.height; w = h * aspecto; }
  etapa.style.width = Math.floor(w) + 'px';
  etapa.style.height = Math.floor(h) + 'px';
  pintarEtapa();
}
new ResizeObserver(ajustarEtapa).observe(etapaCaja);

function pintarEtapa() {
  pintarCursor();
  const H = etapa.clientHeight;
  const v = actual();
  etapa.classList.toggle('sinvideo', !v);
  $('vacio').hidden = !!(v && S.cuadroDe);
  // logo
  const ml = $('mLogo');
  ml.style.left = S.logo.x * 100 + '%';
  ml.style.top = S.logo.y * 100 + '%';
  ml.style.width = S.logo.w * 100 + '%';
  $('imgMarca').style.opacity = 1 - S.logo.transp / 100;
  const fl = $('fondoLogo'), lwPx = S.logo.w * etapa.clientWidth;
  fl.style.opacity = (S.logo.fondo || 0) / 100;
  fl.style.inset = -(lwPx * 0.06) + 'px';
  fl.style.borderRadius = lwPx * 0.08 + 'px';
  // texto
  const mt = $('mTexto');
  const est = estiloTexto(S.texto.color);
  const T = lineas(), mtx = mt.querySelector('.mt-txt');
  mtx.textContent = '';
  T.bloques.forEach((bq, bi) => {
    const dv = el('div', { text: bq.join('\n') });
    if (bi) dv.style.marginTop = T.hueco * 1.35 + 'em';
    mtx.append(dv);
  });
  mt.style.left = S.texto.x * 100 + '%';
  mt.style.top = S.texto.y * 100 + '%';
  mt.style.fontSize = (S.texto.tam / 100) * H + 'px';
  mt.style.color = S.texto.color;
  mt.style.background = est.caja;
  mt.style.textShadow = est.sombra ? `0.06em 0.06em 0 ${est.sombra}` : 'none';
  // zonas (se reutilizan los nodos para no cortar un arrastre en curso)
  const cont = $('zonasEtapa');
  const t = v ? v.t : 0;
  const lista = v ? v.zonas : [];
  const ids = new Set(lista.map((z) => String(z.id)));
  [...cont.children].forEach((n) => { if (!ids.has(n.dataset.id)) n.remove(); });
  lista.forEach((z, i) => {
    let d = cont.querySelector(`[data-id="${z.id}"]`);
    if (!d) {
      d = el('div', { 'data-id': z.id, title: 'Arrastrá para mover · esquina para agrandar' },
        el('span', { class: 'rot' }), el('span', { class: 'info-z' }), el('span', { class: 'asa', 'data-asa': '1' }),
        conCruz(el('button', { type: 'button', class: 'cerrar', title: 'Quitar esta zona', 'aria-label': 'Quitar esta zona', onclick: (e) => {
          e.stopPropagation();
          const v = actual(); if (!v || S.procesando) return;
          const i = v.zonas.findIndex((x) => x.id === z.id);
          if (i >= 0) v.zonas.splice(i, 1);
          if (S.zonaSel === z.id) S.zonaSel = null;
          pintarTodo();
        } })));
      arrastrar(d, {
        inicio: () => { S.zonaSel = z.id; pintarZonas(); return { x: z.x, y: z.y, w: z.w, h: z.h }; },
        mover: (o, dx, dy) => { z.x = clamp(o.x + dx, 0, 1 - z.w); z.y = clamp(o.y + dy, 0, 1 - z.h); },
        agrandar: (o, dx, dy) => { z.w = clamp(o.w + dx, 0.02, 1 - z.x); z.h = clamp(o.h + dy, 0.02, 1 - z.y); },
        fin: () => pintarZonas()
      });
      cont.append(d);
    }
    const fuera = !z.todo && (t < (z.desde || 0) || (z.hasta != null && t > z.hasta));
    d.className = `zona ${z.tipo}${z.forma === 'redonda' ? ' redonda' : ''}${fuera ? ' fuera' : ''}${S.zonaSel === z.id ? ' sel' : ''}`;
    d.firstChild.textContent = nombreZona(z, i);
    // ayuda solo en pantalla (no se graba en la copia)
    const durZ = v && v.info ? v.info.duracion : 0;
    d.querySelector('.info-z').textContent = z.todo || !durZ ? 'Zona de censura · todo el video'
      : `Zona de censura desde ${fmtLargo(z.desde || 0)}` + (z.hasta == null ? ' hasta el final' : ` hasta ${fmtLargo(z.hasta)}`);
    Object.assign(d.style, { left: z.x * 100 + '%', top: z.y * 100 + '%', width: z.w * 100 + '%', height: z.h * 100 + '%' });
  });
}

function arrastrar(nodo, { inicio, mover, agrandar, fin }) {
  nodo.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    if (e.target.closest('.cerrar')) return;
    e.preventDefault();
    const esAsa = !!e.target.dataset.asa;
    const r = etapa.getBoundingClientRect();
    const o = inicio();
    const px = e.clientX, py = e.clientY;
    nodo.setPointerCapture(e.pointerId);
    const mov = (ev) => {
      const dx = (ev.clientX - px) / r.width, dy = (ev.clientY - py) / r.height;
      (esAsa && agrandar ? agrandar : mover)(o, dx, dy);
      pintarEtapa();
    };
    const sol = () => {
      nodo.removeEventListener('pointermove', mov);
      nodo.removeEventListener('pointerup', sol);
      nodo.removeEventListener('pointercancel', sol);
      if (fin) fin();
      guardarAjustes();
      pintarControles();
    };
    nodo.addEventListener('pointermove', mov);
    nodo.addEventListener('pointerup', sol);
    nodo.addEventListener('pointercancel', sol);
  });
}

arrastrar($('mLogo'), {
  inicio: () => ({ ...S.logo }),
  mover: (o, dx, dy) => {
    const hf = (S.logo.w * etapa.clientWidth * LOGO_PROP) / etapa.clientHeight;
    S.logo.x = clamp(o.x + dx, 0, 1 - S.logo.w);
    S.logo.y = clamp(o.y + dy, 0, Math.max(0, 1 - hf));
  },
  agrandar: (o, dx) => { S.logo.w = clamp(o.w + dx, 0.05, Math.min(0.6, 1 - S.logo.x)); }
});
arrastrar($('mTexto'), {
  inicio: () => ({ ...S.texto, w0: $('mTexto').offsetWidth / etapa.clientWidth }),
  mover: (o, dx, dy) => {
    const mt = $('mTexto');
    const wf = mt.offsetWidth / etapa.clientWidth, hf = mt.offsetHeight / etapa.clientHeight;
    S.texto.x = clamp(o.x + dx, 0, Math.max(0, 1 - wf));
    S.texto.y = clamp(o.y + dy, 0, Math.max(0, 1 - hf));
  },
  // esquina: agranda o achica todo el texto (es lo mismo que la barra "Tamaño del texto")
  agrandar: (o, dx) => {
    if (!o.w0) return;
    const maxF = Math.max(0.1, (1 - o.x) / o.w0);
    const f = clamp((o.w0 + dx) / o.w0, 0.1, maxF);
    S.texto.tam = Math.round(clamp(o.tam * f, 1.5, 6) * 10) / 10;
    pintarControles();
  }
});

let pedidoCuadro = 0;
async function traerCuadro() {
  const v = actual();
  if (!v || !v.info) { S.cuadroDe = null; $('cuadro').style.display = 'none'; pintarEtapa(); return; }
  const n = ++pedidoCuadro;
  const r = await ipc.cuadro(v.ruta, v.t, S.alto);
  if (n !== pedidoCuadro) return;
  if (r.ok) {
    $('cuadro').src = r.dataUrl;
    $('cuadro').style.display = 'block';
    S.cuadroDe = v.ruta;
    aspecto = r.ow / r.oh;
    ajustarEtapa();
  }
}

/* ---------- línea de tiempo ---------- */
function pintarTiempo() {
  const v = actual();
  const dur = v && v.info ? v.info.duracion : 0;
  const r = $('tiempo');
  r.max = Math.max(0.1, dur);
  r.value = v ? v.t : 0;
  r.disabled = !v || !v.info;
  $('tFin').textContent = fmt(dur);
  $('tAct').textContent = v ? `Línea de tiempo · ${fmt(v.t)}` : 'Línea de tiempo';
  const b = $('barras');
  b.textContent = '';
  (v ? v.zonas : []).forEach((z, i) => b.append(barraZona(v, z, i, dur)));
  pintarCursor();
}

/* ---------- barras de zonas con marcadores arrastrables ---------- */
const MARCADOR = '<svg width="16" height="18" viewBox="0 0 16 18" aria-hidden="true"><path d="M2 1h12a1 1 0 0 1 1 1v9l-7 6-7-6V2a1 1 0 0 1 1-1z" fill="currentColor" stroke="#fff" stroke-width="1.2"/></svg>';
function tramo(z, dur) {
  const d = z.todo ? 0 : clamp(z.desde || 0, 0, dur);
  const h = z.todo || z.hasta == null ? dur : clamp(z.hasta, d, dur);
  return [d, h];
}
function barraZona(v, z, i, dur) {
  const pista = el('div', { class: 'pista-z' });
  const act = el('i', { class: 'act-z' });
  const cur = el('b', { class: 'cur-z' });
  const color = z.tipo === 'negro' ? 'var(--grafito-claro)' : 'var(--gris)';
  act.style.background = color;
  const mIni = el('button', { type: 'button', class: 'marcador', title: 'Arrastrá para elegir desde cuándo tapa', 'aria-label': `Inicio de la zona ${i + 1}` });
  const mFin = el('button', { type: 'button', class: 'marcador', title: 'Arrastrá para elegir hasta cuándo tapa', 'aria-label': `Fin de la zona ${i + 1}` });
  mIni.innerHTML = MARCADOR; mFin.innerHTML = MARCADOR;
  mIni.style.color = color; mFin.style.color = color;
  const glob = el('span', { class: 'glob-z' });
  glob.style.background = color;
  if (z.tipo === 'negro') glob.style.color = '#FFFFFF';
  pista.append(act, cur, mIni, mFin, glob);
  const ubicar = () => {
    const [d, h] = tramo(z, dur);
    const a = dur ? d / dur * 100 : 0, c = dur ? h / dur * 100 : 100;
    act.style.left = a + '%'; act.style.width = Math.max(0.4, c - a) + '%';
    mIni.style.left = a + '%'; mFin.style.left = c + '%';
  };
  ubicar();
  const arrastrar = (marc, esIni) => marc.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || S.procesando || !dur) return;
    e.preventDefault();
    detener(false);
    marc.setPointerCapture(e.pointerId);
    S.zonaSel = z.id;
    if (z.todo) { z.todo = false; z.desde = 0; z.hasta = null; }
    pista.classList.add('arrastrando');
    const mover = (ev) => {
      const r = pista.getBoundingClientRect();
      let t = Math.round(clamp((ev.clientX - r.left) / r.width, 0, 1) * dur * 10) / 10;
      const [d, h] = tramo(z, dur);
      if (esIni) { t = Math.min(t, h - 1); z.desde = Math.max(0, t); }
      else { t = Math.max(t, d + 1); z.hasta = t >= dur - 0.05 ? null : Math.min(dur, t); }
      ubicar();
      glob.textContent = (esIni ? 'desde ' : 'hasta ') + fmt(esIni ? z.desde : (z.hasta == null ? dur : z.hasta));
      glob.style.left = (esIni ? mIni : mFin).style.left;
      irA(esIni ? z.desde : (z.hasta == null ? dur : z.hasta));
    };
    const soltar = () => {
      marc.removeEventListener('pointermove', mover);
      marc.removeEventListener('pointerup', soltar);
      marc.removeEventListener('pointercancel', soltar);
      pista.classList.remove('arrastrando');
      const [d, h] = tramo(z, dur);
      if (d <= 0.5 && h >= dur - 0.5) { z.todo = true; z.desde = 0; z.hasta = null; }
      pintarZonas();
      pintarEtapa();
    };
    mover(e);
    marc.addEventListener('pointermove', mover);
    marc.addEventListener('pointerup', soltar);
    marc.addEventListener('pointercancel', soltar);
  });
  arrastrar(mIni, true);
  arrastrar(mFin, false);
  return el('div', { class: 'barra-z' }, el('span', { text: nombreZona(z, i) }), pista);
}
function pintarCursor() {
  const v = actual();
  const dur = v && v.info ? v.info.duracion : 0;
  const pos = dur && v ? clamp(v.t / dur, 0, 1) * 100 + '%' : '0%';
  document.querySelectorAll('#barras .cur-z').forEach((c) => { c.style.left = pos; });
}
let esperaCuadro = null;
$('tiempo').addEventListener('input', (e) => irA(+e.target.value));

/* ---------- reproducción (solo para buscar momentos) ---------- */
const vid = $('vid');
const R = { tocando: false, modo: null, mute: false, giro: 0 }; // modo: 'video' | 'cuadros'
function urlArchivo(ruta) {
  const partes = ruta.replace(/\\/g, '/').split('/');
  return 'file:///' + partes.map((p, i) => (i === 0 && /^[A-Za-z]:$/.test(p) ? p : encodeURIComponent(p))).join('/').replace(/^\/+/, '');
}
// ¿Lo puede reproducir el Chrome interno? Se prueba una vez por video.
function probarVideo(v) {
  if (v.reproducible !== undefined) return Promise.resolve(v.reproducible);
  return new Promise((res) => {
    const t = document.createElement('video');
    let listo = false;
    const fin = (ok) => { if (listo) return; listo = true; t.removeAttribute('src'); t.load(); v.reproducible = ok; res(ok); };
    t.preload = 'metadata';
    t.muted = true;
    t.onloadedmetadata = () => fin(t.videoWidth > 0);
    t.onerror = () => fin(false);
    setTimeout(() => fin(false), 5000);
    t.src = urlArchivo(v.ruta);
  });
}
function irA(t) {
  const v = actual(); if (!v || !v.info) return;
  v.t = clamp(t, 0, Math.max(0, v.info.duracion - 0.05));
  $('tiempo').value = v.t;
  $('tAct').textContent = `Línea de tiempo · ${fmt(v.t)}`;
  pintarEtapa();
  if (R.modo === 'video') {
    try { vid.currentTime = v.t; } catch (_) {}
  } else if (!(R.tocando && R.modo === 'cuadros')) {
    clearTimeout(esperaCuadro);
    esperaCuadro = setTimeout(traerCuadro, 120);
  }
}
function pintarRep() {
  const v = actual();
  const hay = !!(v && v.info) && !S.procesando;
  ['repAtras', 'repPlay', 'repAdelante'].forEach((id) => { $(id).disabled = !hay; });
  $('repPlay').classList.toggle('tocando', R.tocando);
  $('repPlay').setAttribute('aria-label', R.tocando ? 'Pausar' : 'Reproducir');
  const sinSonido = R.modo === 'cuadros' || (v && v.reproducible === false) || (v && v.info && !v.info.audio);
  $('repMute').disabled = !hay || sinSonido;
  $('repMute').classList.toggle('silencio', R.mute);
  $('repMute').setAttribute('aria-label', R.mute ? 'Activar sonido' : 'Silenciar');
  $('repMute').title = R.mute ? 'Activar sonido' : 'Silenciar';
  $('repAviso').hidden = !(v && v.reproducible === false);
}
function detener(ocultarVideo) {
  R.tocando = false; R.giro++;
  try { vid.pause(); } catch (_) {}
  if (ocultarVideo) {
    R.modo = null;
    vid.classList.remove('on');
    vid.removeAttribute('src');
    try { vid.load(); } catch (_) {}
  }
  pintarRep();
}
let ultimoPinte = 0;
vid.addEventListener('timeupdate', () => {
  const v = actual(); if (!v || R.modo !== 'video') return;
  v.t = vid.currentTime;
  const ahora = performance.now();
  if (ahora - ultimoPinte > 200) {
    ultimoPinte = ahora;
    $('tiempo').value = v.t;
    $('tAct').textContent = `Línea de tiempo · ${fmt(v.t)}`;
    pintarEtapa();
  }
});
vid.addEventListener('ended', () => { R.tocando = false; pintarRep(); });
vid.addEventListener('pause', () => { if (R.modo === 'video') { R.tocando = false; pintarRep(); } });
async function reproducir() {
  const v = actual(); if (!v || !v.info || S.procesando) return;
  if (v.t >= v.info.duracion - 0.2) v.t = 0;
  R.tocando = true; pintarRep();
  const ok = await probarVideo(v);
  if (!R.tocando || v !== actual()) return;
  if (ok) {
    R.modo = 'video';
    const url = urlArchivo(v.ruta);
    if (vid.dataset.ruta !== v.ruta) { vid.src = url; vid.dataset.ruta = v.ruta; }
    vid.muted = R.mute;
    try { vid.currentTime = v.t; } catch (_) {}
    vid.classList.add('on');
    try { await vid.play(); } catch (_) { v.reproducible = false; vid.classList.remove('on'); R.modo = null; return reproducir(); }
  } else {
    // formato que el Chrome interno no reproduce: se avanza mostrando cuadros sueltos
    R.modo = 'cuadros';
    pintarRep();
    const giro = ++R.giro;
    let antes = performance.now();
    while (R.tocando && giro === R.giro && v === actual()) {
      const r = await ipc.cuadro(v.ruta, v.t, Math.min(S.alto, 720));
      if (!R.tocando || giro !== R.giro || v !== actual()) break;
      if (r.ok) { $('cuadro').src = r.dataUrl; $('cuadro').style.display = 'block'; }
      let pasado = performance.now() - antes;
      if (pasado < 250) { await new Promise((r) => setTimeout(r, 250 - pasado)); pasado = 250; }
      if (!R.tocando || giro !== R.giro || v !== actual()) break;
      antes = performance.now();
      v.t = Math.min(v.info.duracion, v.t + pasado / 1000);
      $('tiempo').value = v.t;
      $('tAct').textContent = `Línea de tiempo · ${fmt(v.t)}`;
      pintarEtapa();
      if (v.t >= v.info.duracion - 0.05) break;
    }
    if (giro === R.giro) { R.tocando = false; R.modo = null; pintarRep(); }
  }
  pintarRep();
}
function alternar() { if (R.tocando) detener(false); else reproducir(); }
$('repPlay').addEventListener('click', alternar);
$('repAtras').addEventListener('click', () => { const v = actual(); if (v) irA(v.t - 10); });
$('repAdelante').addEventListener('click', () => { const v = actual(); if (v) irA(v.t + 10); });
$('repMute').addEventListener('click', () => { R.mute = !R.mute; vid.muted = R.mute; pintarRep(); });
document.addEventListener('keydown', (e) => {
  const t = e.target;
  if (t && (t.tagName === 'INPUT' && t.type !== 'range' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  const v = actual(); if (!v || !v.info || S.procesando) return;
  if (e.code === 'Space') { e.preventDefault(); alternar(); }
  else if (e.key === 'ArrowLeft') { e.preventDefault(); irA(v.t - 10); }
  else if (e.key === 'ArrowRight') { e.preventDefault(); irA(v.t + 10); }
});

/* ---------- cola de videos ---------- */
const TEXTO_ESTADO = {
  analizando: () => 'Revisando el video…',
  listo: () => 'Listo para marcar',
  marcando: (v) => `Marcando… ${Math.floor((v.pct || 0) * 100)}%`,
  hecho: () => 'Terminado',
  error: () => 'No se pudo marcar',
  ilegible: () => 'No se pudo leer este archivo',
  cancelado: () => 'Cancelado'
};

function pintarCola() {
  if (typeof revisarOla === 'function' && window.OLA_OK) revisarOla();
  const ul = $('cola');
  ul.textContent = '';
  S.videos.forEach((v, i) => {
    const li = el('li', { class: i === S.sel ? 'sel' : '', title: v.error || v.ruta, onclick: () => seleccionar(i) },
      el('span', { class: 'nom', text: v.nombre }),
      el('span', { class: 'est', text: TEXTO_ESTADO[v.estado](v) }));
    if (v.estado === 'marcando') {
      const i2 = el('i'); i2.style.width = Math.floor((v.pct || 0) * 100) + '%';
      li.append(el('div', { class: 'barra' }, i2));
    }
    if (v.estado === 'hecho') li.append(el('button', { type: 'button', class: 'ver', text: 'Ver archivo', onclick: (e) => { e.stopPropagation(); ipc.mostrar(v.salida); } }));
    if (!S.procesando) li.append(conCruz(el('button', { type: 'button', class: 'quitar', title: 'Quitar de la lista', 'aria-label': `Quitar ${v.nombre}`, onclick: (e) => { e.stopPropagation(); quitar(i); } })));
    ul.append(li);
  });
  const n = S.videos.length;
  $('colaTitulo').textContent = n ? `Cola · ${n} ${n === 1 ? 'video' : 'videos'}` : 'Sin videos';
  pintarBoton();
}

function seleccionar(i) {
  if (i === S.sel) return;
  detener(true);
  S.sel = i; S.zonaSel = null;
  pintarTodo();
  const li = $('cola').children[i];
  if (li) li.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  traerCuadro();
}
function quitar(i) {
  detener(true);
  S.videos.splice(i, 1);
  if (S.sel >= S.videos.length) S.sel = S.videos.length - 1;
  S.cuadroDe = null;
  pintarTodo();
  traerCuadro();
}

async function agregar(rutas) {
  if (!S.ffmpeg || S.procesando) return;
  const nuevas = rutas.filter((r) => r && !S.videos.some((v) => v.ruta === r) && !/\(MARCADO\)\.mp4$/i.test(r));
  if (!nuevas.length) return;
  const primero = S.videos.length;
  nuevas.forEach((r) => S.videos.push({ ruta: r, nombre: r.split(/[\\/]/).pop(), estado: 'analizando', zonas: [], t: 0 }));
  if (S.sel < 0) S.sel = primero;
  pintarTodo();
  for (const v of S.videos.slice(primero)) {
    const r = await ipc.analizar(v.ruta);
    if (r.ok) { v.info = r.info; v.estado = 'listo'; v.t = Math.min(5, r.info.duracion * 0.1); }
    else { v.estado = 'ilegible'; v.error = r.error; }
    pintarCola();
    if (v === actual()) { pintarZonas(); traerCuadro(); }
  }
}

// El cuadro de arrastre cambia según el momento: cargar / cancelar / cargar nuevos.
function terminado() {
  return !S.procesando && S.videos.length > 0 && !pendientes().length && S.videos.some((v) => v.estado === 'hecho') && !S.videos.some((v) => v.estado === 'analizando');
}
const SOLTAR = {
  cargar: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></svg><strong>Arrastrá los videos acá</strong><span>o hacé clic para elegirlos</span>',
  cancelar: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/></svg><strong>Cancelar marcado</strong><span>se detiene el video en curso</span>',
  nuevo: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg><strong>Iniciar nueva sesión</strong><span>limpia la cola finalizada para comenzar un nuevo marcado</span>'
};
function pintarSoltar() {
  const b = $('soltar'), m = S.procesando ? 'cancelar' : terminado() ? 'nuevo' : 'cargar';
  if (b.dataset.modo === m) return;
  b.dataset.modo = m;
  b.classList.toggle('s-cancelar', m === 'cancelar');
  b.classList.toggle('s-nuevo', m === 'nuevo');
  b.innerHTML = SOLTAR[m];
}
function vaciarCola() {
  detener(false);
  S.videos = []; S.sel = -1;
  // sesión nueva: logo, cuadro de texto y zoom vuelven a los valores de fábrica (se conservan los textos del logo)
  const ini = JSON.parse(JSON.stringify(AJUSTES_INICIALES));
  S.logo = { ...ini.logo, l1: S.logo.l1, l2: S.logo.l2 }; S.texto = ini.texto;
  guardarAjustes(); ponerZoom(1); pintarControles();
  pintarTodo(); traerCuadro();
}
$('soltar').addEventListener('click', async () => {
  if (S.procesando) { await ipc.cancelar(); return; }
  if (terminado()) { vaciarCola(); return; }
  agregar(await ipc.elegir());
});
window.addEventListener('dragover', (e) => { e.preventDefault(); document.body.classList.add('arrastrando'); });
window.addEventListener('dragleave', (e) => { if (!e.relatedTarget) document.body.classList.remove('arrastrando'); });
window.addEventListener('drop', (e) => {
  e.preventDefault();
  document.body.classList.remove('arrastrando');
  if (S.procesando) return;
  const rutas = [...e.dataTransfer.files].map((f) => ipc.rutaDe(f));
  if (terminado() && rutas.length) vaciarCola();
  agregar(rutas);
});

/* ---------- zonas de censura ---------- */
function nuevaZona(tipo) {
  const v = actual(); if (!v) return;
  // cada zona nueva aparece corrida respecto de la anterior (escalera), para que no queden encimadas
  v.nz = (v.nz || 0) + 1;
  const k = (v.nz - 1) % 6;
  const z = { id: idZona++, tipo, forma: 'rect', x: 0.4 + 0.04 * k, y: 0.3 + 0.05 * k, w: 0.2, h: 0.25, todo: true, desde: 0, hasta: null };
  v.zonas.push(z);
  S.zonaSel = z.id;
  pintarTodo();
}
$('agNegra').addEventListener('click', () => nuevaZona('negro'));
$('agBlur').addEventListener('click', () => nuevaZona('desenfoque'));

function pintarZonas() {
  const v = actual();
  const cont = $('listaZonas');
  cont.textContent = '';
  if (!v || !v.zonas.length) {
    cont.append(el('p', { class: 'nada', text: v ? 'Sin zonas. Usá «+ Zona negra» o «+ Desenfoque» para tapar una parte del video.' : 'Elegí un video para agregar zonas.' }));
  }
  (v ? v.zonas : []).forEach((z, i) => {
    const fila = el('div', { class: 'fila-zona' + (S.zonaSel === z.id ? ' sel' : ''), onclick: () => { if (S.zonaSel !== z.id) { S.zonaSel = z.id; pintarZonas(); pintarEtapa(); } } });
    const punto = el('span', { class: 'punto' }); punto.style.background = z.tipo === 'negro' ? 'var(--grafito-claro)' : 'var(--gris)';
    fila.append(el('div', { class: 'fz-cab' }, punto, el('span', { text: nombreZona(z, i) }),
      el('button', { type: 'button', class: 'quitar-z', text: 'Quitar', onclick: (e) => { e.stopPropagation(); v.zonas.splice(i, 1); pintarTodo(); } })));
    const sw = el('div', { class: 'interruptor', role: 'group', 'aria-label': `Tipo de la zona ${i + 1}` });
    [['negro', 'Negro'], ['desenfoque', 'Desenfoque']].forEach(([k, t]) => sw.append(el('button', {
      type: 'button', 'aria-pressed': String(z.tipo === k), text: t, onclick: () => { z.tipo = k; pintarTodo(); }
    })));
    fila.append(sw);
    // forma de la zona: rectangular u ovalada
    const fo = el('div', { class: 'fz-forma', role: 'group', 'aria-label': `Forma de la zona ${i + 1}` }, el('span', { text: 'Forma' }));
    [['rect', 'Rectangular', '<rect x="1.5" y="1.5" width="19" height="12" rx="2"/>'], ['redonda', 'Redonda', '<ellipse cx="11" cy="7.5" rx="9.5" ry="6"/>']].forEach(([k, t, dib]) => {
      const b = el('button', { type: 'button', title: t, 'aria-label': t, 'aria-pressed': String((z.forma || 'rect') === k), onclick: (e) => { e.stopPropagation(); z.forma = k; pintarZonas(); pintarEtapa(); } });
      b.innerHTML = `<svg width="22" height="15" viewBox="0 0 22 15" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2">${dib}</g></svg>`;
      fo.append(b);
    });
    fila.append(fo);
    const chk = el('input', { type: 'checkbox', id: `todo${z.id}` });
    chk.checked = z.todo;
    chk.addEventListener('change', () => { z.todo = chk.checked; pintarTodo(); });
    fila.append(el('label', { class: 'fz-todo', for: `todo${z.id}` }, chk, 'Todo el video'));
    if (!z.todo) {
      const campo = (k, rotulo, txtBtn) => {
        const inp = el('input', { class: 'fld', id: `${k}${z.id}`, value: z[k] == null ? '' : fmt(z[k]), placeholder: k === 'hasta' ? 'hasta el final' : '00:00' });
        inp.addEventListener('change', () => { z[k] = leerTiempo(inp.value); if (k === 'desde' && z[k] == null) z[k] = 0; pintarTodo(); });
        const btn = el('button', { type: 'button', text: txtBtn, onclick: () => { z[k] = Math.round(v.t); pintarTodo(); } });
        return el('div', {}, el('label', { class: 'lbl', for: `${k}${z.id}`, text: rotulo }), inp, btn);
      };
      fila.append(el('div', { class: 'fz-tiempos' }, campo('desde', 'Desde', 'Usar momento actual'), campo('hasta', 'Hasta', 'Usar momento actual')));
    }
    cont.append(fila);
  });
  const hay = !!(v && v.info) && !S.procesando;
  $('agNegra').disabled = !hay;
  $('agBlur').disabled = !hay;
  pintarTiempo();
  pintarRep();
}

/* ---------- controles de la derecha ---------- */
document.querySelectorAll('[data-k]').forEach((inp) => {
  inp.value = S.datos[inp.dataset.k];
  inp.addEventListener('input', () => {
    S.datos[inp.dataset.k] = inp.value;
    if (inp.dataset.k === 'dependencia') { try { localStorage.setItem('marca2.dependencia', inp.value); } catch (_) {} }
    pintarEtapa(); pintarBoton();
  });
});
// texto del logo
// el texto del logo no se recuerda: cada vez que se abre vuelve a GRABACIÓN COMPARTIDA
S.logo.l1 = LOGO_DEF[0];
S.logo.l2 = LOGO_DEF[1];
[['fLogo1', 'l1'], ['fLogo2', 'l2']].forEach(([id, k]) => {
  const inp = $(id);
  inp.value = S.logo[k];
  inp.addEventListener('input', () => { S.logo[k] = inp.value; guardarAjustes(); dibujarLogo(); });
});

function pintarSwitch(id, valor) {
  document.querySelectorAll(`#${id} button`).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === String(valor))));
}
$('swModo').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; S.modo = b.dataset.v; guardarAjustes(); pintarControles(); });
$('swAlto').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  S.alto = +b.dataset.v; guardarAjustes(); pintarControles();
});
$('colores').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; S.texto.color = b.dataset.c; guardarAjustes(); pintarControles(); pintarEtapa(); });
$('rTransp').addEventListener('input', (e) => { S.logo.transp = +e.target.value; guardarAjustes(); pintarControles(); pintarEtapa(); });
$('rFondoLogo').addEventListener('input', (e) => { S.logo.fondo = +e.target.value; guardarAjustes(); pintarControles(); pintarEtapa(); });
$('rTamLogo').addEventListener('input', (e) => { S.logo.w = Math.min(+e.target.value / 100, 1 - S.logo.x); guardarAjustes(); pintarControles(); pintarEtapa(); });
$('formatos').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; S.texto.formato = b.dataset.f; pintarControles(); pintarEtapa();
  const mt = $('mTexto'), et = mt.offsetParent;
  if (et && et.clientHeight) { const sob = (mt.offsetTop + mt.offsetHeight) / et.clientHeight - 0.98; if (sob > 0) { S.texto.y = Math.max(0.02, S.texto.y - sob); pintarEtapa(); } }
  guardarAjustes(); });
$('rFondoTexto').addEventListener('input', (e) => { S.texto.fondo = +e.target.value; guardarAjustes(); pintarControles(); pintarEtapa(); });
$('rTamTexto').addEventListener('input', (e) => { S.texto.tam = +e.target.value; guardarAjustes(); pintarControles(); pintarEtapa(); });

function pintarControles() {
  pintarSwitch('swModo', S.modo);
  pintarSwitch('swAlto', S.alto);
  document.querySelectorAll('#colores button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.c === S.texto.color)));
  $('rTransp').value = S.logo.transp;
  $('rTamLogo').value = Math.round(S.logo.w * 100);
  $('rFondoLogo').value = S.logo.fondo || 0;
  $('lFondoLogo').textContent = S.logo.fondo ? `Fondo negro detrás del logo · ${S.logo.fondo}%` : 'Fondo negro detrás del logo · sin fondo';
  $('rTamTexto').value = S.texto.tam;
  $('vTransp').textContent = S.logo.transp + '%';
  $('vFondoLogo').textContent = S.logo.fondo ? S.logo.fondo + '%' : 'Sin fondo';
  $('vTamLogo').textContent = Math.round(S.logo.w * 100) + '%';
  $('lTamTexto').textContent = `Tamaño del texto · ${(+S.texto.tam).toFixed(1)}`;
  if (S.texto.fondo == null) S.texto.fondo = 50;
  document.querySelectorAll('#formatos button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.f === (S.texto.formato || 'original'))));
  $('rFondoTexto').value = S.texto.fondo;
  $('lFondoTexto').textContent = `Transparencia del cuadro de texto · ${S.texto.fondo}%`;
  $('vTamTexto').textContent = (+S.texto.tam).toFixed(1).replace('.', ',');
  $('vFondoTexto').textContent = S.texto.fondo + '%';
}

/* ---------- marcar ---------- */
function faltantes() {
  const f = [];
  if (!S.datos.fecha.trim()) f.push('la fecha de entrega');
  if (!S.datos.localidad.trim()) f.push('la localidad');
  if (!S.datos.nombre.trim()) f.push('el profesional');
  if (!S.datos.dependencia.trim()) f.push('la dependencia');
  return f;
}
function pendientes() { return S.videos.filter((v) => ['listo', 'error', 'cancelado'].includes(v.estado)); }

function pintarBoton() {
  const b = $('marcar'), aviso = $('aviso');
  $('fFecha').classList.toggle('falta', !S.datos.fecha.trim());
  $('fNombre').classList.toggle('falta', !S.datos.nombre.trim());
  $('fLocalidad').classList.toggle('falta', !S.datos.localidad.trim());
  $('fDependencia').classList.toggle('falta', !S.datos.dependencia.trim());
  pintarSoltar();
  if (S.procesando) {
    const i = S.lote ? S.lote.findIndex((v) => v.estado === 'marcando') + 1 : 0;
    b.textContent = S.lote ? `Marcando ${Math.max(1, i)} de ${S.lote.length}…` : 'Marcando…';
    b.classList.remove('cancelar', 'b-hecho'); b.classList.add('b-marcando'); b.disabled = true;
    aviso.hidden = true; return;
  }
  if (terminado()) {
    const h = S.videos.filter((v) => v.estado === 'hecho').length;
    b.innerHTML = `${h} ${h === 1 ? 'video marcado' : 'videos marcados'}<svg class="tilde" width="26" height="26" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="#1E8A4F"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`; b.classList.remove('cancelar', 'b-marcando'); b.classList.add('b-hecho'); b.disabled = true;
    aviso.hidden = true; return;
  }
  b.classList.remove('cancelar', 'b-marcando', 'b-hecho');
  const n = pendientes().length;
  b.textContent = n ? `Marcar ${n} ${n === 1 ? 'video' : 'videos'}` : 'Marcar videos';
  const f = faltantes();
  let msg = '';
  if (!S.ffmpeg) msg = 'No se encontró ffmpeg.exe. Copialo en la carpeta del programa y volvé a abrirlo.';
  else if (f.length) msg = `Completá ${f.join(' y ')} para poder marcar.`;
  aviso.textContent = msg;
  aviso.hidden = !msg;
  b.disabled = !n || !!msg;
}

$('marcar').addEventListener('click', async () => {
  if (S.procesando) { await ipc.cancelar(); return; }
  detener(false);
  S.procesando = true;
  pintarTodo();
  OLA.lleno = false; OLA.actual = 0; if (OLA.tf) OLA.tf.fill(-1); olaA(0);
  S.lote = pendientes(); iniciarRestante();
  S.lote.forEach((v) => { v.pct = 0; });
  for (const v of pendientes()) {
    if (!S.procesando) break;
    v.estado = 'marcando'; v.pct = 0; v.error = null;
    pintarCola();
    const tam = await ipc.tamano(v.ruta, S.alto);
    const capa = tam.ok ? await generarCapa(tam.ow, tam.oh) : null;
    const r = await ipc.marcar({ archivo: v.ruta, alto: S.alto, modo: S.modo, zonas: v.zonas.map((z) => ({ ...z })), capa });
    if (r.ok) { v.estado = 'hecho'; v.salida = r.salida; }
    else if (r.cancelado) { v.estado = 'cancelado'; S.procesando = false; }
    else { v.estado = 'error'; v.error = r.error; }
    avanceLote();
    pintarCola();
  }
  pararRestante();
  const cancelado = S.lote.some((v) => v.estado === 'cancelado');
  S.lote = null;
  if (cancelado) { OLA.actual = 0; olaA(0); }
  else { olaA(1); OLA.lleno = true; OLA.firma = S.videos.map((v) => v.ruta).join('|'); }
  S.procesando = false;
  pintarTodo();
});
function avanceLote() {
  if (!S.lote || !S.lote.length) return;
  let tot = 0, hecho = 0;
  for (const v of S.lote) {
    const d = (v.info && v.info.duracion) || 1;
    tot += d;
    hecho += d * (v.estado === 'hecho' || v.estado === 'error' ? 1 : v.estado === 'marcando' ? (v.pct || 0) : 0);
  }
  olaA(hecho / tot);
  S.fracLote = hecho / tot;
}

/* ---------- tiempo restante de toda la cola ---------- */
const REST = { t0: 0, iv: 0, mostrado: null };
function fmtRestante(seg) {
  seg = Math.max(0, Math.round(seg));
  const h = Math.floor(seg / 3600), m = Math.floor((seg % 3600) / 60), s = seg % 60;
  return (h ? `${h} h ` : '') + (h || m ? `${m} min ` : '') + `${s} seg`;
}
function iniciarRestante() {
  pararRestante();
  S.fracLote = 0; REST.t0 = performance.now(); REST.mostrado = null;
  const r = $('restante'); r.hidden = false; r.textContent = 'Calculando tiempo restante…';
  REST.iv = setInterval(() => {
    const pas = (performance.now() - REST.t0) / 1000, f = S.fracLote || 0;
    if (pas < 15 || f < 0.003) return;
    const est = pas / f * (1 - f);
    if (REST.mostrado == null) REST.mostrado = est;
    else { REST.mostrado = Math.max(0, REST.mostrado - 1); REST.mostrado += (est - REST.mostrado) * 0.08; }
    r.textContent = 'Tiempo restante: ' + fmtRestante(REST.mostrado);
  }, 1000);
}
function pararRestante() { clearInterval(REST.iv); REST.iv = 0; $('restante').hidden = true; }

ipc.alProgreso(({ archivo, p }) => {
  const v = S.videos.find((x) => x.ruta === archivo && x.estado === 'marcando');
  if (!v) return;
  const antes = Math.floor((v.pct || 0) * 100);
  v.pct = p;
  avanceLote();
  if (Math.floor(p * 100) !== antes) pintarCola();
});

/* ---------- aviso de contenido oculto en la columna derecha ---------- */
// Barra de desplazamiento propia (riel con flechas), para cualquier lista.
function instalarRiel(lista, riel, { marco, ocultarSiSobra } = {}) {
  const pista = riel.querySelector('.riel-pista'), barra = riel.querySelector('.riel-barra');
  const [fArr, fAb] = riel.querySelectorAll('.riel-flecha');
  const actualizar = () => {
    if (marco) {
      marco.classList.toggle('hay-arriba', lista.scrollTop > 4);
      marco.classList.toggle('hay-abajo', lista.scrollTop + lista.clientHeight < lista.scrollHeight - 4);
    }
    const H = pista.clientHeight, prop = Math.min(1, lista.clientHeight / Math.max(1, lista.scrollHeight));
    const alto = Math.max(28, H * prop), libre = H - alto, max = lista.scrollHeight - lista.clientHeight;
    barra.style.height = alto + 'px';
    barra.style.top = (max > 0 ? (lista.scrollTop / max) * libre : 0) + 'px';
    riel.classList.toggle('lleno', prop >= 1);
    if (ocultarSiSobra) riel.classList.toggle('sobra', prop >= 1);
  };
  fArr.addEventListener('click', () => lista.scrollBy({ top: -90, behavior: 'smooth' }));
  fAb.addEventListener('click', () => lista.scrollBy({ top: 90, behavior: 'smooth' }));
  pista.addEventListener('pointerdown', (e) => {
    if (e.target === barra) {
      e.preventDefault();
      barra.setPointerCapture(e.pointerId);
      barra.classList.add('tomada');
      const y0 = e.clientY, s0 = lista.scrollTop;
      const libre = pista.clientHeight - barra.offsetHeight, max = lista.scrollHeight - lista.clientHeight;
      const mov = (ev) => { if (libre > 0) lista.scrollTop = s0 + ((ev.clientY - y0) / libre) * max; };
      const sol = () => { barra.classList.remove('tomada'); barra.removeEventListener('pointermove', mov); barra.removeEventListener('pointerup', sol); barra.removeEventListener('pointercancel', sol); };
      barra.addEventListener('pointermove', mov); barra.addEventListener('pointerup', sol); barra.addEventListener('pointercancel', sol);
    } else {
      const r = barra.getBoundingClientRect();
      lista.scrollBy({ top: (e.clientY < r.top ? -1 : 1) * lista.clientHeight * 0.85, behavior: 'smooth' });
    }
  });
  lista.addEventListener('scroll', actualizar, { passive: true });
  new ResizeObserver(actualizar).observe(lista);
  new ResizeObserver(actualizar).observe(pista);
  new MutationObserver(() => requestAnimationFrame(actualizar)).observe(lista, { childList: true, subtree: true });
  actualizar();
  return actualizar;
}
instalarRiel($('der'), $('riel'), { marco: $('derCaja') });
const actualizarRielCola = instalarRiel($('cola'), $('rielCola'), { marco: $('colaMarco'), ocultarSiSobra: true });
// La lista usa el diseño grande mientras todos los videos entran sin scroll; si no, pasa a compacta.
function decidirCola() {
  const m = $('colaMarco'), l = $('cola');
  const top = l.scrollTop;
  m.classList.remove('compacta');
  const noEntra = l.scrollHeight > l.clientHeight + 2;
  m.classList.toggle('compacta', noEntra);
  l.scrollTop = top;
  actualizarRielCola();
}
new ResizeObserver(() => requestAnimationFrame(decidirCola)).observe($('colaMarco'));
new MutationObserver(() => requestAnimationFrame(decidirCola)).observe($('cola'), { childList: true });
$('pArriba').addEventListener('click', () => $('der').scrollBy({ top: -$('der').clientHeight * 0.7, behavior: 'smooth' }));
$('pAbajo').addEventListener('click', () => $('der').scrollBy({ top: $('der').clientHeight * 0.7, behavior: 'smooth' }));

/* ---------- zoom de toda la pantalla ---------- */
let zoom = 1;
function ponerZoom(z) {
  zoom = Math.round(clamp(z, 0.5, 2) * 10) / 10;
  if (ipc.zoom) ipc.zoom(zoom);
  $('zPct').textContent = Math.round(zoom * 100) + '%';
  $('zMenos').disabled = zoom <= 0.5;
  $('zMas').disabled = zoom >= 2;
  try { localStorage.setItem('marca2.zoom', String(zoom)); } catch (_) {}
}
$('zMenos').addEventListener('click', () => ponerZoom(zoom - 0.1));
$('zMas').addEventListener('click', () => ponerZoom(zoom + 0.1));
$('zValor').addEventListener('click', () => ponerZoom(1));
document.addEventListener('keydown', (e) => {
  if (!e.ctrlKey || e.altKey) return;
  if (e.key === '+' || e.key === '=' || e.code === 'NumpadAdd') { e.preventDefault(); ponerZoom(zoom + 0.1); }
  else if (e.key === '-' || e.code === 'NumpadSubtract') { e.preventDefault(); ponerZoom(zoom - 0.1); }
  else if (e.key === '0' || e.code === 'Numpad0') { e.preventDefault(); ponerZoom(1); }
});
ponerZoom(zoom);

/* ---------- inicio ---------- */
function pintarTodo() {
  pintarCola();
  pintarZonas();
  pintarControles();
  pintarEtapa();
  pintarRep();
}

$('logoOfiju').src = window.LOGOS.pieOfiju;
$('escudoPJ').src = window.LOGOS.escudo;
// Logo del programa: las olas se llenan como barra de avance total.
// Degradé azul OFIJU → celeste, frente curvo (abajo adelanta), humo blanco que se disuelve y glow.
const OLA = { actual: 0, meta: 0, lleno: false, firma: '', raf: 0, listo: false };
(function () {
  const caja = $('logoPrograma');
  const txt = atob(window.LOGOS.programa.split(',')[1]);
  caja.innerHTML = txt;
  const svg = caja.querySelector('svg');
  svg.setAttribute('aria-hidden', 'true');
  const cv = document.createElement('canvas'); cv.className = 'ola-capa'; caja.append(cv);
  // máscara: solo las olas, en blanco
  const doc = new DOMParser().parseFromString(txt, 'image/svg+xml'), r = doc.documentElement;
  [...r.children].forEach((n) => { if (!(n.tagName === 'path' && n.getAttribute('fill') === '#999999')) n.remove(); else n.setAttribute('fill', '#fff'); });
  const vb = svg.viewBox.baseVal, W = 360, H = Math.round(W * vb.height / vb.width);
  r.setAttribute('width', W); r.setAttribute('height', H);
  cv.width = W; cv.height = H;
  const img = new Image();
  img.onload = () => {
    const t = document.createElement('canvas'); t.width = W; t.height = H;
    const g = t.getContext('2d'); g.drawImage(img, 0, 0);
    const m = g.getImageData(0, 0, W, H).data;
    // ruido suave (humo)
    const ruido = (n) => { const c = document.createElement('canvas'); c.width = c.height = n; const x = c.getContext('2d'), d = x.createImageData(n, n);
      for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
      x.putImageData(d, 0, 0); g.clearRect(0, 0, W, H); g.imageSmoothingQuality = 'high'; g.drawImage(c, 0, 0, W, H); return g.getImageData(0, 0, W, H).data; };
    const r1 = ruido(14), r2 = ruido(34);
    const idx = [], al = [];
    let x0 = W, x1 = 0, y0 = H, y1 = 0;
    for (let i = 0; i < W * H; i++) if (m[i * 4 + 3] > 8) {
      idx.push(i); al.push(m[i * 4 + 3] / 255);
      const x = i % W, y = (i / W) | 0;
      if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
    }
    const L = (x1 - x0) * 0.42, n = idx.length;
    const px = new Float32Array(n), ns = new Float32Array(n), gr = new Float32Array(n);
    idx.forEach((i, k) => {
      const x = i % W, y = (i / W) | 0, t = Math.min(1, Math.max(0, (y1 - y) / (y1 - y0)));
      px[k] = x + L * (1 - Math.sqrt(1 - t * t));            // posición "efectiva" con frente curvo
      const v = (0.65 * r1[i * 4] + 0.35 * r2[i * 4]) / 255; ns[k] = v;
      gr[k] = (x - x0) / (x1 - x0);
    });
    let mn = 1, mx = 0; for (const v of ns) { if (v < mn) mn = v; if (v > mx) mx = v; }
    for (let k = 0; k < n; k++) ns[k] = (ns[k] - mn) / (mx - mn || 1);
    Object.assign(OLA, { cv, ctx: cv.getContext('2d'), idx, al, px, ns, gr, x0, span: (x1 - x0) + L, tf: new Float32Array(n).fill(-1), listo: true });
    OLA.img = OLA.ctx.createImageData(W, H);
    pintarOla(performance.now());
  };
  img.src = 'data:image/svg+xml;base64,' + btoa(new XMLSerializer().serializeToString(r));
})();
// Ruido suave periódico en X (ancho W): al correrse W píxeles vuelve exactamente al mismo dibujo.
function crearRuido(W, H, celda) {
  const nx = Math.round(W / celda), ny = Math.ceil(H * 1.4 / celda) + 2, g = new Float32Array(nx * ny);
  for (let i = 0; i < g.length; i++) g[i] = Math.random();
  const lisa = (t) => t * t * (3 - 2 * t);
  return (x, y) => {
    const fx = x / celda, fy = y / celda, ix = Math.floor(fx), iy = Math.floor(fy), tx = lisa(fx - ix), ty = lisa(fy - iy);
    const x0 = ((ix % nx) + nx) % nx, x1 = (x0 + 1) % nx, y0 = ((iy % ny) + ny) % ny, r0 = y0 * nx, r1 = ((y0 + 1) % ny) * nx;
    const a = g[r0 + x0] + (g[r0 + x1] - g[r0 + x0]) * tx, b = g[r1 + x0] + (g[r1 + x1] - g[r1 + x0]) * tx;
    return a + (b - a) * ty;
  };
}
const HUMO_CICLO = 8000; // ms: en un ciclo la capa 1 recorre W y la capa 2 recorre 2W → loop exacto
function pintarOla(ahora) {
  if (!OLA.listo) return false;
  if (!OLA.n1) { OLA.n1 = crearRuido(OLA.cv.width, OLA.cv.height, 40); OLA.n2 = crearRuido(OLA.cv.width, OLA.cv.height, 18); }
  const W = OLA.cv.width, fase = (ahora % HUMO_CICLO) / HUMO_CICLO, d1 = fase * W, d2 = fase * 2 * W;
  const { idx, al, px, ns, gr, tf, img } = OLA, d = img.data;
  const borde = OLA.x0 + OLA.span * OLA.actual;
  let vivo = !!S.procesando && OLA.actual > 0.002;   // mientras marca, el humo se mueve siempre
  d.fill(0);
  for (let k = 0; k < idx.length; k++) {
    const a = Math.min(1, Math.max(0, (borde - px[k]) / 3 + 0.5));
    if (a <= 0) { tf[k] = -1; continue; }
    if (tf[k] < 0) tf[k] = ahora;
    const dist = (borde - px[k]) / (OLA.span * 0.25);   // humo: franja fija detrás de la punta
    let s = 1;
    if (dist < 1.2 || OLA.finT) {
      const x = idx[k] % W, y = (idx[k] - x) / W;
      const nv = 0.62 * OLA.n1(x - d1, y) + 0.38 * OLA.n2(x - d2, y * 1.3);
      s = Math.min(1, Math.max(0, Math.max(dist * 1.2, OLA.finT ? (ahora - OLA.finT) / 1000 * 0.6 : 0) - (nv - 0.5) * 2.2));
    }
    if (s < 1) vivo = true;
    const f = gr[k];
    const cr = 13 + (90 - 13) * f, cg = 103 + (200 - 103) * f, cb = 155 + (245 - 155) * f;
    const o = idx[k] * 4;
    d[o] = 235 + (cr - 235) * s; d[o + 1] = 248 + (cg - 248) * s; d[o + 2] = 255 + (cb - 255) * s;
    d[o + 3] = 255 * a * al[k];
  }
  OLA.ctx.putImageData(img, 0, 0);
  return vivo;
}
function animarOla(ahora) {
  const dif = OLA.meta - OLA.actual;
  OLA.actual = Math.abs(dif) < 0.0005 ? OLA.meta : OLA.actual + dif * (dif > 0 ? 0.05 : 0.2);
  const humo = pintarOla(ahora);
  OLA.raf = (OLA.actual !== OLA.meta || humo) ? requestAnimationFrame(animarOla) : 0;
}
function olaA(p) { OLA.meta = Math.max(0, Math.min(1, p)); OLA.finT = OLA.meta >= 1 ? (OLA.finT || performance.now()) : 0; if (!OLA.raf) OLA.raf = requestAnimationFrame(animarOla); }
// vuelve a gris cuando cambia la cola (se carga o se borra un video)
window.OLA_OK = true;
function revisarOla() {
  if (!OLA.lleno) return;
  if (S.videos.map((v) => v.ruta).join('|') !== OLA.firma) { OLA.lleno = false; olaA(0); }
}
$('imgMarca').src = window.LOGOS.marca;
dibujarLogo();
pintarTodo();
ajustarEtapa();
// easter egg: clic en la versión → busca actualización ahora
$('version').addEventListener('click', async () => {
  const e = $('version');
  if (!ipc.buscarVersion || e.dataset.ocupado) return;
  const vuelta = (txt, ms) => { e.textContent = txt; setTimeout(() => { e.textContent = 'v.' + (S.version || ''); delete e.dataset.ocupado; e.classList.remove('buscando'); }, ms); };
  if (S.procesando) return vuelta('esperá a que termine de marcar', 2500);
  e.dataset.ocupado = '1'; e.classList.add('buscando'); e.textContent = 'buscando';
  const r = await ipc.buscarVersion();
  e.classList.remove('buscando');
  if (r === 'aldia') vuelta('✔ al día · v.' + (S.version || ''), 3000);
  else if (r === 'error') vuelta('sin conexión', 3000);
  else vuelta('v.' + (S.version || ''), 0);
});
// cartel de actualización: queda en pantalla hasta el reinicio
const PASOS_ACT = ['Bajando la actualización', 'Verificando el archivo', 'Descomprimiendo', 'Instalando', 'Reiniciando el programa'];
if (ipc.alActualizar) ipc.alActualizar(({ version, paso, p, estado, msg }) => {
  $('actualizando').hidden = false;
  $('actTit').textContent = `Actualizando Marca de agua a la versión ${version}`;
  const ul = $('actPasos'); ul.textContent = '';
  PASOS_ACT.forEach((t, i) => {
    const li = el('li', { class: i < paso ? 'ok' : i === paso ? (estado === 'error' ? 'mal' : 'act') : '' });
    li.append(el('i', { text: i < paso ? '✔' : i === paso ? (estado === 'error' ? '✖' : '●') : '○' }), el('span', { text: t + (i === paso && estado !== 'error' ? '…' : '') }));
    const m = el('div', { class: 'mini' }); const bb = el('b'); bb.style.width = (i < paso ? 100 : i === paso ? Math.round((p || 0) * 100) : 0) + '%'; m.append(bb);
    li.append((i === 0 || i === 2) ? m : el('span'));
    ul.append(li);
  });
  const pie = $('actPie'), btn = $('actBtn');
  if (estado === 'error') {
    pie.textContent = `No se pudo actualizar: ${msg}. El programa sigue con la versión actual.`;
    btn.hidden = false; btn.textContent = 'Seguir con la versión actual'; btn.onclick = () => { $('actualizando').hidden = true; };
  } else if (estado === 'reinicio') {
    pie.textContent = '✔ Actualización instalada. Marca de agua se está volviendo a abrir. Si no se abre en unos segundos, abrilo desde el escritorio.';
    btn.hidden = false; btn.textContent = 'Cerrar ahora'; btn.onclick = () => ipc.salir();
  } else { pie.textContent = 'No cierres esta ventana'; btn.hidden = true; }
});
ipc.iniciar().then((r) => {
  S.ffmpeg = r.ffmpeg;
  if (r.version) { S.version = r.version; $('version').textContent = 'v.' + r.version; }
  if (!r.ffmpeg) $('vacio').textContent = 'No se encontró ffmpeg.exe. Copialo en la carpeta del programa y volvé a abrirlo.';
  pintarBoton();
});
