'use strict';
// Motor de marcado: todo lo que habla con ffmpeg. Sin dependencias de Electron,
// para poder probarlo por separado con node.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

/* ---------- utilidades ---------- */

const par = (n) => Math.max(2, Math.round(n / 2) * 2);
const parAbajo = (n) => Math.max(2, Math.floor(n / 2) * 2);

function buscarFfmpeg(carpetas) {
  const nombres = process.platform === 'win32' ? ['ffmpeg.exe'] : ['ffmpeg'];
  for (const c of carpetas.filter(Boolean)) {
    for (const n of nombres) {
      const p = path.join(c, n);
      try { if (fs.statSync(p).isFile()) return p; } catch (_) {}
    }
  }
  return 'ffmpeg'; // en el PATH, si existe
}

function correr(ff, args, { alSalir, alLinea } = {}) {
  return new Promise((resolve) => {
    let hijo;
    try {
      hijo = spawn(ff, args, { windowsHide: true });
    } catch (e) {
      resolve({ code: -1, stdout: Buffer.alloc(0), stderr: String(e) });
      return;
    }
    const out = [];
    let err = '';
    let resto = '';
    hijo.stdout.on('data', (d) => {
      out.push(d);
      if (alLinea) {
        resto += d.toString();
        const ls = resto.split(/\r?\n/);
        resto = ls.pop();
        ls.forEach(alLinea);
      }
    });
    hijo.stderr.on('data', (d) => { err += d.toString(); if (err.length > 200000) err = err.slice(-100000); });
    hijo.on('error', (e) => resolve({ code: -1, stdout: Buffer.concat(out), stderr: err + String(e) }));
    hijo.on('close', (code) => resolve({ code, stdout: Buffer.concat(out), stderr: err }));
    if (alSalir) alSalir(hijo);
  });
}

async function ffmpegDisponible(ff) {
  const r = await correr(ff, ['-hide_banner', '-version']);
  return r.code === 0;
}

/* ---------- análisis del video ---------- */

async function analizar(ff, archivo) {
  const r = await correr(ff, ['-hide_banner', '-i', archivo]);
  const e = r.stderr;
  const lineas = e.split(/\r?\n/);
  const lv = lineas.find((l) => /Stream #\d+:\d+.*: Video:/.test(l) && !/attached pic/.test(l));
  if (!lv) throw new Error('No se encontró imagen de video en el archivo.');
  const md = e.match(/Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/);
  const duracion = md ? (+md[1]) * 3600 + (+md[2]) * 60 + parseFloat(md[3]) : 0;
  const mt = lv.match(/, (\d{2,5})x(\d{2,5})/);
  if (!mt) throw new Error('No se pudo leer el tamaño del video.');
  const w = +mt[1], h = +mt[2];
  let sarN = 1, sarD = 1;
  const ms = lv.match(/SAR (\d+):(\d+)/);
  if (ms && +ms[1] > 0 && +ms[2] > 0) { sarN = +ms[1]; sarD = +ms[2]; }
  let dispW = w * sarN / sarD, dispH = h;
  const mr = e.match(/rotation of (-?\d+(?:\.\d+)?) degrees/);
  const rot = mr ? Math.abs(Math.round(parseFloat(mr[1]))) % 180 : 0;
  if (rot === 90) [dispW, dispH] = [dispH, dispW];
  const entrelazado = /\b(top first|bottom first|top coded first|bottom coded first)\b/.test(lv);
  const la = lineas.find((l) => /Stream #\d+:\d+.*: Audio:/.test(l));
  const audio = !!la;
  // si el audio ya es AAC se copia tal cual (no se recomprime: más rápido, sin pérdida y sin riesgo de trabarse)
  const audioAac = !!la && /Audio: aac\b/.test(la);
  return { duracion, w, h, dispW, dispH, entrelazado, audio, audioAac };
}

// Tamaño de salida: el lado corto del video pasa a ser `alto` (720 o 1080).
function tamanoSalida(info, alto) {
  if (info.dispW >= info.dispH) return { ow: par(alto * info.dispW / info.dispH), oh: alto };
  return { ow: alto, oh: par(alto * info.dispH / info.dispW) };
}

function filtroBase(info, ow, oh) {
  return (info.entrelazado ? 'yadif=deint=interlaced,' : '') + `scale=${ow}:${oh},setsar=1`;
}

/* ---------- cuadro para la vista previa ---------- */

async function cuadro(ff, archivo, info, segundo, alto) {
  const { ow, oh } = tamanoSalida(info, alto);
  const t = Math.max(0, Math.min(segundo, Math.max(0, info.duracion - 0.1)));
  const r = await correr(ff, ['-hide_banner', '-loglevel', 'error', '-ss', t.toFixed(3), '-i', archivo,
    '-frames:v', '1', '-vf', filtroBase(info, ow, oh), '-f', 'image2pipe', '-c:v', 'mjpeg', '-q:v', '3', 'pipe:1']);
  if (r.code !== 0 || !r.stdout.length) throw new Error('No se pudo obtener la imagen del video.');
  return { dataUrl: 'data:image/jpeg;base64,' + r.stdout.toString('base64'), ow, oh };
}

/* ---------- aceleración por placa de video ---------- */

async function detectarAceleracion(ff) {
  const r = await correr(ff, ['-hide_banner', '-encoders']);
  const lista = r.stdout.toString();
  for (const c of ['h264_nvenc', 'h264_qsv', 'h264_amf']) {
    if (!new RegExp('\\s' + c + '\\s').test(lista)) continue;
    const p = await correr(ff, ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'color=c=black:s=640x360:d=0.3',
      '-c:v', c, '-f', 'null', '-']);
    if (p.code === 0) return c;
  }
  return null;
}

function argsCodec(modo, acel) {
  if (modo === 'lento') return ['-c:v', 'libx264', '-preset', 'medium', '-crf', '18'];
  switch (acel) {
    case 'h264_nvenc': return ['-c:v', 'h264_nvenc', '-preset', 'p4', '-rc', 'vbr', '-cq', '23', '-b:v', '0'];
    case 'h264_qsv': return ['-c:v', 'h264_qsv', '-preset', 'veryfast', '-global_quality', '23'];
    case 'h264_amf': return ['-c:v', 'h264_amf', '-quality', 'speed', '-rc', 'cqp', '-qp_i', '22', '-qp_p', '24'];
    default: return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22'];
  }
}

/* ---------- armado del filtro ---------- */

// zona: { tipo:'negro'|'desenfoque', x,y,w,h (fracciones 0..1), todo:bool, desde, hasta (segundos) }
function zonaPx(z, ow, oh) {
  const W = Math.min(ow, Math.max(8, par(z.w * ow)));
  const H = Math.min(oh, Math.max(8, par(z.h * oh)));
  const X = Math.min(ow - W, Math.max(0, parAbajo(z.x * ow)));
  const Y = Math.min(oh - H, Math.max(0, parAbajo(z.y * oh)));
  return { X, Y, W, H };
}

function habilitar(z) {
  if (z.todo) return '';
  const d = Math.max(0, +z.desde || 0);
  const h = z.hasta == null || z.hasta === '' ? 1e9 : Math.max(d, +z.hasta);
  return `:enable='between(t,${d.toFixed(2)},${h.toFixed(2)})'`;
}

function armarFiltro(info, ow, oh, zonas, conCapa) {
  const partes = [`[0:v]${filtroBase(info, ow, oh)}[v0]`];
  let cur = 'v0';
  (zonas || []).forEach((z, i) => {
    const n = i + 1;
    const { X, Y, W, H } = zonaPx(z, ow, oh);
    const en = habilitar(z);
    // máscara redonda (óvalo que ocupa todo el recuadro), con 2 px de borde suave
    const mascara = `format=yuva420p,geq=lum='lum(X,Y)':cb='cb(X,Y)':cr='cr(X,Y)':a='255*clip((1-hypot((X-W/2)/(W/2),(Y-H/2)/(H/2)))*min(W,H)/4,0,1)'`;
    if (z.tipo === 'desenfoque') {
      const r = Math.max(1, Math.min(30, Math.floor(Math.min(W, H) / 4) - 1));
      partes.push(`[${cur}]split=2[a${n}][b${n}]`);
      partes.push(`[b${n}]crop=${W}:${H}:${X}:${Y},boxblur=${r}:3${z.forma === 'redonda' ? ',' + mascara : ''}[c${n}]`);
      partes.push(`[a${n}][c${n}]overlay=${X}:${Y}${en}[v${n}]`);
    } else if (z.forma === 'redonda') {
      partes.push(`[${cur}]split=2[a${n}][b${n}]`);
      partes.push(`[b${n}]crop=${W}:${H}:${X}:${Y},format=yuva420p,geq=lum=16:cb=128:cr=128:a='255*clip((1-hypot((X-W/2)/(W/2),(Y-H/2)/(H/2)))*min(W,H)/4,0,1)'[c${n}]`);
      partes.push(`[a${n}][c${n}]overlay=${X}:${Y}${en}[v${n}]`);
    } else {
      partes.push(`[${cur}]drawbox=x=${X}:y=${Y}:w=${W}:h=${H}:color=black:t=fill${en}[v${n}]`);
    }
    cur = `v${n}`;
  });
  if (conCapa) { partes.push(`[${cur}][1:v]overlay=0:0[vm]`); cur = 'vm'; }
  partes.push(`[${cur}]format=yuv420p[vout]`);
  return partes.join(';');
}

function nombreSalida(archivo) {
  const p = path.parse(archivo);
  return path.join(p.dir, `${p.name} (MARCADO).mp4`);
}

function armarArgs({ archivo, info, alto, zonas, capa, modo, acel, salida, tolerante }) {
  const { ow, oh } = tamanoSalida(info, alto);
  const args = ['-hide_banner', '-nostdin', '-y', '-nostats', '-loglevel', 'error', '-progress', 'pipe:1'];
  // modo tolerante: rehace los tiempos internos y saltea cuadros dañados en vez de trabarse
  if (tolerante) args.push('-fflags', '+genpts+discardcorrupt', '-err_detect', 'ignore_err');
  args.push('-i', archivo);
  if (capa) args.push('-i', capa);
  args.push('-filter_complex', armarFiltro(info, ow, oh, zonas, !!capa), '-map', '[vout]', '-map', '0:a:0?');
  args.push(...argsCodec(modo, acel));
  if (tolerante) args.push('-max_muxing_queue_size', '4096');
  if (info.audioAac) args.push('-c:a', 'copy');
  else {
    args.push('-c:a', 'aac', '-b:a', '160k');
    if (tolerante) args.push('-af', 'aresample=async=1:first_pts=0');
  }
  args.push('-movflags', '+faststart', salida || nombreSalida(archivo));
  return args;
}

/* ---------- marcado ---------- */

const SIN_AVANCE = +process.env.MARCA_SIN_AVANCE || 75; // segundos sin avanzar antes de considerar que ffmpeg se trabó

function minSeg(t) {
  t = Math.max(0, Math.floor(t));
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), x = t % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
}

// Devuelve { ok, salida, error, aviso }.
// 1.º intento: normal (con placa de video si hay). Si falla o se traba,
// 2.º intento: con el procesador y en modo tolerante, como el sistema anterior.
async function marcar(ff, job, alProgreso, alProceso) {
  const salida = job.salida || nombreSalida(job.archivo);
  const intentar = (acel, tolerante) => new Promise((resolve) => {
    let ultimo = -1, cuando = Date.now(), fin = false, hijo = null, trabado = false;
    const vig = setInterval(() => {
      if (fin || job.cancelado) return;
      if ((Date.now() - cuando) / 1000 > SIN_AVANCE && hijo && !trabado) {
        trabado = true;
        try { hijo.kill(); } catch (_) {}
        // si el proceso no libera sus salidas, no esperamos más
        setTimeout(() => { clearInterval(vig); resolve({ code: -1, stdout: Buffer.alloc(0), stderr: '', trabado: true, hasta: Math.max(0, ultimo) }); }, 4000);
      }
    }, 5000);
    correr(ff, armarArgs({ ...job, acel, salida, tolerante }), {
      alSalir: (h) => { hijo = h; if (alProceso) alProceso(h); },
      alLinea: (l) => {
        if (l === 'progress=end') { fin = true; return; }
        const m = l.match(/^out_time_(?:us|ms)=(\d+)/);
        if (!m) return;
        const t = +m[1] / 1e6;
        if (t > ultimo + 0.01) { ultimo = t; cuando = Date.now(); }
        if (job.info.duracion > 0) {
          if (t / job.info.duracion >= 0.995) fin = true; // el cierre del archivo no informa avance
          if (alProgreso) alProgreso(Math.min(0.999, t / job.info.duracion));
        }
      }
    }).then((r) => { clearInterval(vig); resolve({ ...r, trabado, hasta: Math.max(0, ultimo) }); });
  });

  let r = await intentar(job.acel, false);
  let aviso = null;
  if (r.code !== 0 && !job.cancelado) {
    const donde = r.trabado ? r.hasta : null;
    if (alProgreso) alProgreso(0);
    r = await intentar(null, true);
    if (r.code === 0 && donde != null) aviso = `Se trabó cerca del minuto ${minSeg(donde)} y se terminó por el método alternativo (procesador). Revisá la copia en ese punto.`;
  }
  if (r.code !== 0) {
    try { fs.unlinkSync(salida); } catch (_) {}
    if (job.cancelado) return { ok: false, salida, error: 'Cancelado' };
    const error = r.trabado
      ? `El video parece dañado cerca del minuto ${minSeg(r.hasta)}. No se pudo terminar la copia.`
      : (r.stderr || '').trim().split(/\r?\n/).slice(-3).join(' ') || 'Error desconocido';
    return { ok: false, salida, error };
  }
  if (alProgreso) alProgreso(1);
  return { ok: true, salida, aviso };
}

module.exports = {
  buscarFfmpeg, ffmpegDisponible, analizar, tamanoSalida, cuadro, detectarAceleracion,
  armarFiltro, armarArgs, nombreSalida, marcar, zonaPx
};
