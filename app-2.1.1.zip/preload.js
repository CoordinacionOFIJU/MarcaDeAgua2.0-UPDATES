'use strict';
const { contextBridge, ipcRenderer, webUtils, webFrame } = require('electron');

contextBridge.exposeInMainWorld('api', {
  iniciar: () => ipcRenderer.invoke('iniciar'),
  elegir: () => ipcRenderer.invoke('elegir'),
  analizar: (a) => ipcRenderer.invoke('analizar', a),
  cuadro: (a, s, alto) => ipcRenderer.invoke('cuadro', a, s, alto),
  tamano: (a, alto) => ipcRenderer.invoke('tamano', a, alto),
  marcar: (t) => ipcRenderer.invoke('marcar', t),
  cancelar: () => ipcRenderer.invoke('cancelar'),
  mostrar: (a) => ipcRenderer.invoke('mostrar', a),
  rutaDe: (archivo) => { try { return webUtils.getPathForFile(archivo); } catch (_) { return archivo.path || ''; } },
  alProgreso: (fn) => ipcRenderer.on('progreso', (_e, d) => fn(d)),
  salir: () => ipcRenderer.invoke('salir'),
  buscarVersion: () => ipcRenderer.invoke('buscarVersion'),
  alActualizar: (fn) => ipcRenderer.on('actualizando', (_e, d) => fn(d)),
  zoom: (f) => { try { webFrame.setZoomFactor(f); } catch (_) {} }
});
