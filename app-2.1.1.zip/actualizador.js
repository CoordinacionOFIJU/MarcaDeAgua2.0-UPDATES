'use strict';
// Actualización automática de Marca de agua 2.0.
// Solo baja la parte del programa (resources\app). Nunca envía datos ni videos:
// lo único que hace es leer version.json y, si el usuario acepta, bajar app.zip.
const { app, dialog, net } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const BASE = 'https://raw.githubusercontent.com/CoordinacionOFIJU/MarcaDeAgua2.0-UPDATES/main/';

const num = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0);
function esMasNueva(a, b) { // ¿a > b?
  const x = num(a), y = num(b);
  for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}

async function bajar(url, alAvance) {
  const r = await net.fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error('el servidor respondió ' + r.status);
  const total = +r.headers.get('content-length') || 0;
  const lector = r.body.getReader(), partes = []; let n = 0;
  for (;;) {
    const { done, value } = await lector.read();
    if (done) break;
    partes.push(Buffer.from(value)); n += value.length;
    if (alAvance && total) alAvance(n / total);
  }
  return Buffer.concat(partes);
}

// Descompresor de .zip mínimo (stored y deflate), sin dependencias.
async function descomprimir(buf, destino, alAvance) {
  let e = buf.length - 22;
  while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error('el archivo de actualización está dañado');
  const cantidad = buf.readUInt16LE(e + 10);
  let p = buf.readUInt32LE(e + 16);
  for (let i = 0; i < cantidad; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip inválido');
    const metodo = buf.readUInt16LE(p + 10), comp = buf.readUInt32LE(p + 20);
    const ln = buf.readUInt16LE(p + 28), lx = buf.readUInt16LE(p + 30), lc = buf.readUInt16LE(p + 32);
    const local = buf.readUInt32LE(p + 42);
    const nombre = buf.toString('utf8', p + 46, p + 46 + ln);
    p += 46 + ln + lx + lc;
    const ruta = path.join(destino, nombre);
    if (!ruta.startsWith(destino + path.sep)) continue; // nada fuera de la carpeta
    if (nombre.endsWith('/')) { fs.mkdirSync(ruta, { recursive: true }); continue; }
    const ini = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
    const datos = buf.subarray(ini, ini + comp);
    fs.mkdirSync(path.dirname(ruta), { recursive: true });
    fs.writeFileSync(ruta, metodo === 0 ? datos : zlib.inflateRawSync(datos));
    if (alAvance && i % 4 === 0) { alAvance((i + 1) / cantidad); await new Promise((r) => setTimeout(r, 0)); }
  }
  if (alAvance) alAvance(1);
}

const espera = (ms) => new Promise((r) => setTimeout(r, ms));

// Cambia resources\app por la versión nueva, guardando la actual en app_anterior.
// Primero intenta renombrar carpetas; si Windows no lo permite, copia encima.
function instalar(recursos) {
  const a = path.join(recursos, 'app'), n = path.join(recursos, 'app_nueva'), v = path.join(recursos, 'app_anterior');
  fs.rmSync(v, { recursive: true, force: true });
  try {
    fs.renameSync(a, v);
    try { fs.renameSync(n, a); return; }
    catch (e) { fs.renameSync(v, a); throw e; } // vuelve a dejar la actual
  } catch (_) {
    fs.cpSync(a, v, { recursive: true });
    fs.cpSync(n, a, { recursive: true, force: true });
    fs.rmSync(n, { recursive: true, force: true });
  }
}

// Se llama al abrir. aviso({ paso, p, estado, msg }) muestra el cartel de avance en la ventana.
let ocupado = false;
// manual: consulta pedida con clic en la versión (saltea la copia temporal y devuelve el resultado)
async function revisar(ventana, aviso, { manual = false } = {}) {
  if (!app.isPackaged || process.platform !== 'win32') return 'error';
  if (ocupado) return 'ocupado';
  ocupado = true;
  try { return await revisar2(ventana, aviso, manual); } finally { ocupado = false; }
}
async function revisar2(ventana, aviso, manual) {
  const recursos = process.resourcesPath, nueva = path.join(recursos, 'app_nueva');
  try { fs.rmSync(nueva, { recursive: true, force: true }); } catch (_) {} // restos de un intento anterior
  let info;
  try { info = JSON.parse((await bajar(BASE + 'version.json' + (manual ? '?t=' + Date.now() : ''))).toString('utf8')); }
  catch (_) { return 'error'; } // sin internet o sin publicación: al abrir no se muestra nada
  const actual = app.getVersion();
  if (!info || !info.version) return 'error';
  if (!esMasNueva(info.version, actual)) return 'aldia';

  const r = await dialog.showMessageBox(ventana, {
    type: 'info', buttons: ['Sí, actualizar ahora', 'Ahora no'], defaultId: 0, cancelId: 1, noLink: true,
    title: 'Marca de agua 2.0 · OFIJU',
    message: `Hay una nueva versión de Marca de agua (${info.version}).`,
    detail: `Tenés instalada la ${actual}.${info.notas ? '\n\nNovedades: ' + info.notas : ''}\n\n¿Querés actualizar ahora? El programa se cierra y se vuelve a abrir solo.`
  });
  if (r.response !== 0) return 'nueva';

  const av = (paso, p, extra = {}) => aviso({ version: info.version, paso, p, ...extra });
  let paso = 0;
  try {
    av(0, 0);
    const zip = await bajar(info.url || BASE + 'app.zip', (p) => av(0, p));
    paso = 1; av(1, 0); await espera(300);
    const huella = crypto.createHash('sha256').update(zip).digest('hex');
    if (info.sha256 && huella.toLowerCase() !== String(info.sha256).toLowerCase()) throw new Error('el archivo bajado no coincide con el publicado');
    paso = 2; av(2, 0);
    fs.mkdirSync(nueva, { recursive: true });
    await descomprimir(zip, nueva, (p) => av(2, p));
    const pk = JSON.parse(fs.readFileSync(path.join(nueva, 'package.json'), 'utf8'));
    if (pk.version !== info.version || !fs.existsSync(path.join(nueva, 'main.js'))) throw new Error('la actualización está incompleta');
    paso = 3; av(3, 0); await espera(200);
    instalar(recursos);
    spawnSync('reg', ['add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MarcaDeAguaOFIJU', '/v', 'DisplayVersion', '/t', 'REG_SZ', '/d', info.version, '/f'], { windowsHide: true });
    paso = 4; av(4, 0); await espera(900);
    // reinicio propio de Electron; si por algo no reabre, el cartel ya dice que se abra a mano
    av(4, 0, { estado: 'reinicio' });
    app.relaunch();
    await espera(1200);
    app.exit(0);
  } catch (e) {
    try { fs.rmSync(nueva, { recursive: true, force: true }); } catch (_) {}
    av(paso, 0, { estado: 'error', msg: e.message });
  }
  return 'nueva';
}

module.exports = { revisar, esMasNueva };
