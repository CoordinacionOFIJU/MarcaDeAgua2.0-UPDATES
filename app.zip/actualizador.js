'use strict';
// Actualización automática de Marca de agua 2.0.
// Solo baja la parte del programa (resources\app). Nunca envía datos ni videos:
// lo único que hace es leer version.json y, si el usuario acepta, bajar app.zip.
const { app, dialog, net } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn } = require('child_process');

const BASE = 'https://raw.githubusercontent.com/CoordinacionOFIJU/MarcaDeAgua2.0-UPDATES/main/';

const num = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0);
function esMasNueva(a, b) { // ¿a > b?
  const x = num(a), y = num(b);
  for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}

async function bajar(url, alAvance) {
  const r = await net.fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error('el servidor respondió ' + r.status);
  const total = +r.headers.get('content-length') || 0;
  const lector = r.body.getReader(), partes = []; let n = 0;
  for (;;) {
    const { done, value } = await lector.read();
    if (done) break;
    partes.push(Buffer.from(value)); n += value.length;
    if (alAvance && total) alAvance(n / total);
  }
  return Buffer.concat(partes);
}

// Descompresor de .zip mínimo (stored y deflate), sin dependencias.
function descomprimir(buf, destino) {
  let e = buf.length - 22;
  while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error('el archivo de actualización está dañado');
  const cantidad = buf.readUInt16LE(e + 10);
  let p = buf.readUInt32LE(e + 16);
  for (let i = 0; i < cantidad; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip inválido');
    const metodo = buf.readUInt16LE(p + 10), comp = buf.readUInt32LE(p + 20);
    const ln = buf.readUInt16LE(p + 28), lx = buf.readUInt16LE(p + 30), lc = buf.readUInt16LE(p + 32);
    const local = buf.readUInt32LE(p + 42);
    const nombre = buf.toString('utf8', p + 46, p + 46 + ln);
    p += 46 + ln + lx + lc;
    const ruta = path.join(destino, nombre);
    if (!ruta.startsWith(destino + path.sep)) continue; // nada fuera de la carpeta
    if (nombre.endsWith('/')) { fs.mkdirSync(ruta, { recursive: true }); continue; }
    const ini = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
    const datos = buf.subarray(ini, ini + comp);
    fs.mkdirSync(path.dirname(ruta), { recursive: true });
    fs.writeFileSync(ruta, metodo === 0 ? datos : zlib.inflateRawSync(datos));
  }
}

// Al cerrarse el programa: cambia app por app_nueva (con respaldo) y lo vuelve a abrir.
function aplicarAlCerrar(recursos, version) {
  const ps = `
$ErrorActionPreference='Stop'
try { Wait-Process -Id ${process.pid} -Timeout 30 } catch {}
Start-Sleep -Milliseconds 700
$r='${recursos.replace(/'/g, "''")}'
$a=Join-Path $r 'app'; $n=Join-Path $r 'app_nueva'; $v=Join-Path $r 'app_anterior'
try {
  if (Test-Path $v) { Remove-Item -LiteralPath $v -Recurse -Force }
  Rename-Item -LiteralPath $a -NewName 'app_anterior'
  Rename-Item -LiteralPath $n -NewName 'app'
  & reg add 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\MarcaDeAguaOFIJU' /v DisplayVersion /t REG_SZ /d '${version}' /f | Out-Null
} catch {
  if (-not (Test-Path $a) -and (Test-Path $v)) { Rename-Item -LiteralPath $v -NewName 'app' }
}
Start-Process -FilePath '${process.execPath.replace(/'/g, "''")}'
`;
  const archivo = path.join(os.tmpdir(), 'actualizar_marca_ofiju.ps1');
  fs.writeFileSync(archivo, '﻿' + ps, 'utf8');
  spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', archivo],
    { detached: true, stdio: 'ignore', windowsHide: true }).unref();
}

// Se llama al abrir. aviso(p, texto) muestra el avance en la ventana.
async function revisar(ventana, aviso) {
  if (!app.isPackaged || process.platform !== 'win32') return;
  let info;
  try { info = JSON.parse((await bajar(BASE + 'version.json')).toString('utf8')); }
  catch (_) { return; } // sin internet o sin publicación: no se muestra nada
  const actual = app.getVersion();
  if (!info || !info.version || !esMasNueva(info.version, actual)) return;

  const r = await dialog.showMessageBox(ventana, {
    type: 'info', buttons: ['Sí, actualizar ahora', 'Ahora no'], defaultId: 0, cancelId: 1, noLink: true,
    title: 'Marca de agua 2.0 · OFIJU',
    message: `Hay una nueva versión de Marca de agua (${info.version}).`,
    detail: `Tenés instalada la ${actual}.${info.notas ? '\n\nNovedades: ' + info.notas : ''}\n\n¿Querés actualizar ahora? El programa se cierra y se vuelve a abrir solo.`
  });
  if (r.response !== 0) return;

  const recursos = process.resourcesPath, nueva = path.join(recursos, 'app_nueva');
  try {
    aviso(0, 'Bajando la actualización…');
    const zip = await bajar(info.url || BASE + 'app.zip', (p) => aviso(p, 'Bajando la actualización…'));
    aviso(1, 'Verificando…');
    const huella = crypto.createHash('sha256').update(zip).digest('hex');
    if (info.sha256 && huella.toLowerCase() !== String(info.sha256).toLowerCase()) throw new Error('el archivo bajado no coincide con el publicado');
    fs.rmSync(nueva, { recursive: true, force: true });
    fs.mkdirSync(nueva, { recursive: true });
    descomprimir(zip, nueva);
    const pk = JSON.parse(fs.readFileSync(path.join(nueva, 'package.json'), 'utf8'));
    if (pk.version !== info.version || !fs.existsSync(path.join(nueva, 'main.js'))) throw new Error('la actualización está incompleta');
    aviso(1, 'Reiniciando…');
    aplicarAlCerrar(recursos, info.version);
    setTimeout(() => app.exit(0), 400);
  } catch (e) {
    try { fs.rmSync(nueva, { recursive: true, force: true }); } catch (_) {}
    aviso(-1, '');
    dialog.showMessageBox(ventana, { type: 'warning', title: 'Marca de agua 2.0 · OFIJU', message: 'No se pudo actualizar.', detail: e.message + '\n\nEl programa sigue funcionando con la versión actual.' });
  }
}

module.exports = { revisar, esMasNueva };
