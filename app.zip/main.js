'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const motor = require('./motor');
const actualizador = require('./actualizador');

let ventana = null;
let cartel = null; // cartel flotante "Iniciando…"
let FF = 'ffmpeg';
let acel = null;
let procesoActual = null;
let trabajoActual = null;
let cancelar = false;
const cache = new Map(); // archivo -> info

function carpetasFfmpeg() {
  return [
    process.env.PORTABLE_EXECUTABLE_DIR,
    path.dirname(process.execPath),
    process.resourcesPath,
    app.getAppPath(),
    path.join(app.getAppPath(), '..'),
  ];
}

function crearCartel() {
  cartel = new BrowserWindow({
    width: 380, height: 300, frame: false, resizable: false, movable: true, show: true, center: true,
    backgroundColor: '#2E343F', alwaysOnTop: true, title: 'Iniciando Marca de agua',
    icon: path.join(__dirname, 'icono.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  cartel.removeMenu();
  cartel.loadFile(path.join(__dirname, 'interfaz', 'inicio.html'), { query: { v: app.getVersion() } });
  cartel.on('closed', () => { cartel = null; });
}

function crearVentana() {
  ventana = new BrowserWindow({
    width: 1440, height: 960, minWidth: 800, minHeight: 560, show: false,
    backgroundColor: '#171A21',
    title: 'Marca de agua 2.0 · OFIJU',
    icon: path.join(__dirname, 'icono.png'),
    autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  ventana.removeMenu();
  // siempre arranca maximizado
  ventana.once('ready-to-show', () => {
    ventana.maximize(); ventana.show();
    if (cartel) { const c = cartel; setTimeout(() => { try { c.close(); } catch (_) {} }, 250); }
    // busca versión nueva en segundo plano (no demora la apertura)
    setTimeout(() => actualizador.revisar(ventana, (d) => ventana && ventana.webContents.send('actualizando', d)).catch(() => {}), 1500);
  });
  ventana.loadFile(path.join(__dirname, 'interfaz', 'index.html'));
  ventana.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  ventana.webContents.on('will-navigate', (e) => e.preventDefault());
  // F12 abre las herramientas de diagnóstico
  ventana.webContents.on('before-input-event', (_e, i) => { if (i.type === 'keyDown' && i.key === 'F12') ventana.webContents.toggleDevTools(); });
  ventana.webContents.on('preload-error', (_e, _p, err) => console.error('preload', err));
}

// una sola ventana de Marca a la vez: si se abre otra vez, se trae al frente la que ya está
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (cartel) { cartel.show(); cartel.focus(); return; } if (ventana) { if (ventana.isMinimized()) ventana.restore(); ventana.show(); ventana.focus(); } });
  app.whenReady().then(() => { crearCartel(); crearVentana(); });
}
app.on('window-all-closed', () => { if (!cartel) app.quit(); });
app.on('before-quit', () => { cancelar = true; if (procesoActual) try { procesoActual.kill(); } catch (_) {} });

async function info(archivo) {
  if (!cache.has(archivo)) cache.set(archivo, await motor.analizar(FF, archivo));
  return cache.get(archivo);
}

ipcMain.handle('iniciar', async () => {
  FF = motor.buscarFfmpeg(carpetasFfmpeg());
  const ok = await motor.ffmpegDisponible(FF);
  if (ok) acel = await motor.detectarAceleracion(FF).catch(() => null);
  return { ffmpeg: ok, acelerado: !!acel, version: app.getVersion(), carpeta: path.dirname(process.env.PORTABLE_EXECUTABLE_FILE || process.execPath) };
});

ipcMain.handle('elegir', async () => {
  const r = await dialog.showOpenDialog(ventana, {
    title: 'Elegí los videos a marcar',
    properties: ['openFile', 'multiSelections'],
    filters: [
      { name: 'Videos', extensions: ['mp4', 'avi', 'mkv', 'mov', 'ts', 'mts', 'm2ts', 'wmv', 'mpg', 'mpeg', 'flv', '3gp', 'webm', 'vob', 'm4v', 'asf', 'dav'] },
      { name: 'Todos los archivos', extensions: ['*'] }
    ]
  });
  return r.canceled ? [] : r.filePaths;
});

ipcMain.handle('analizar', async (_e, archivo) => {
  try { return { ok: true, info: await info(archivo), nombre: path.basename(archivo) }; }
  catch (e) { return { ok: false, error: e.message, nombre: path.basename(archivo) }; }
});

ipcMain.handle('cuadro', async (_e, archivo, segundo, alto) => {
  try { return { ok: true, ...(await motor.cuadro(FF, archivo, await info(archivo), segundo, alto)) }; }
  catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('tamano', async (_e, archivo, alto) => {
  try { return { ok: true, ...motor.tamanoSalida(await info(archivo), alto) }; }
  catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('marcar', async (_e, trabajo) => {
  // trabajo: { archivo, alto, modo, zonas, capa (dataURL PNG) }
  cancelar = false;
  let capa = null;
  try {
    const i = await info(trabajo.archivo);
    if (trabajo.capa) {
      capa = path.join(os.tmpdir(), `marca_ofiju_${process.pid}_${Date.now()}.png`);
      fs.writeFileSync(capa, Buffer.from(trabajo.capa.split(',')[1], 'base64'));
    }
    const job = { archivo: trabajo.archivo, info: i, alto: trabajo.alto, zonas: trabajo.zonas, capa, modo: trabajo.modo, acel };
    trabajoActual = job;
    const r = await motor.marcar(FF, job,
      (p) => ventana && ventana.webContents.send('progreso', { archivo: trabajo.archivo, p }),
      (hijo) => { procesoActual = hijo; });
    procesoActual = null;
    trabajoActual = null;
    if (cancelar) return { ok: false, cancelado: true };
    return r;
  } catch (e) {
    return { ok: false, error: e.message };
  } finally {
    if (capa) try { fs.unlinkSync(capa); } catch (_) {}
  }
});

ipcMain.handle('cancelar', () => {
  cancelar = true;
  if (trabajoActual) trabajoActual.cancelado = true;
  if (procesoActual) try { procesoActual.kill(); } catch (_) {}
  return true;
});

ipcMain.handle('salir', () => { app.exit(0); return true; });
ipcMain.handle('mostrar', (_e, archivo) => { shell.showItemInFolder(archivo); return true; });
